import json
from dataclasses import dataclass, field
from typing import List, Any
from .loader import SkillLoader

@dataclass
class TestCaseResult:
    prompt: str
    success: bool = False
    llm_reply: str = ""
    skill_calls: List[dict] = field(default_factory=list)
    error: str = ""

class SkillHarness:
    def __init__(self):
        self.loader = SkillLoader()
        self.skills = self.loader.load_all()
        self.tool_schemas = self.loader.get_all_schemas()
        self.test_records: List[TestCaseResult] = []

    def execute_skill(self, skill_name: str, args: dict) -> Any:
        skill = self.loader.get_skill(skill_name)
        if not skill:
            raise RuntimeError(f"不存在技能：{skill_name}")
        return skill.run(** args)

    def run_pipeline(self, user_prompt: str, llm_client):
        res = TestCaseResult(prompt=user_prompt)
        messages = [{"role": "user", "content": user_prompt}]
        try:
            resp = llm_client.chat.completions.create(
                model="deepseek-chat",
                messages=messages,
                tools=self.tool_schemas,
                temperature=0.1
            )
            msg = resp.choices[0].message

            messages.append(msg.model_dump(exclude_none=True))

            if msg.tool_calls:
                for tool_call in msg.tool_calls:
                    s_name = tool_call.function.name
                    s_args = json.loads(tool_call.function.arguments)
                    res.skill_calls.append({"skill": s_name, "args": s_args})
                    output = self.execute_skill(s_name, s_args)
                    # 工具响应消息
                    tool_msg = {
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": json.dumps(output, ensure_ascii=False)
                    }
                    messages.append(tool_msg)

                # 二次请求生成最终回答
                final_resp = llm_client.chat.completions.create(
                    model="deepseek-chat", messages=messages, temperature=0.1
                )
                res.llm_reply = final_resp.choices[0].message.content
            else:
                res.llm_reply = msg.content
            res.success = True
        except Exception as e:
            res.error = str(e)
            res.success = False
        self.test_records.append(res)
        return res

    def print_report(self):
        print("="*50)
        print("Skill 执行报告")
        print("="*50)
        for item in self.test_records:
            print(f"用户输入：{item.prompt}")
            if item.skill_calls:
                for call in item.skill_calls:
                    print(f"调用技能：{call['skill']} 参数：{call['args']}")
            print(f"模型回复：{item.llm_reply}")
            if item.error:
                print(f"错误：{item.error}")
            print("-"*40)