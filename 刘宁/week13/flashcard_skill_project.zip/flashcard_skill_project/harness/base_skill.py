from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, List

@dataclass
class SkillParam:
    name: str
    desc: str
    type: str
    required: bool = True

@dataclass
class SkillMeta:
    name: str
    description: str
    params: List[SkillParam]

class BaseSkill(ABC):
    @abstractmethod
    def get_meta(self) -> SkillMeta:
        """返回Function Call标准工具元数据"""
        pass

    @abstractmethod
    def run(self, **kwargs) -> Any:
        """技能核心业务执行逻辑"""
        pass

    def get_tool_schema(self) -> dict:
        """转OpenAI标准function schema"""
        meta = self.get_meta()
        props = {}
        required = []
        for p in meta.params:
            props[p.name] = {"type": p.type, "description": p.desc}
            if p.required:
                required.append(p.name)
        return {
            "type": "function",
            "function": {
                "name": meta.name,
                "description": meta.description,
                "parameters": {
                    "type": "object",
                    "properties": props,
                    "required": required
                }
            }
        }
