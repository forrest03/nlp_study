import importlib
import os
from pathlib import Path
from typing import Dict, Optional
from .base_skill import BaseSkill

SKILL_DIR = Path(__file__).parent.parent / "skills"

class SkillLoader:
    def __init__(self):
        self.skill_map: Dict[str, BaseSkill] = {}

    def load_all(self) -> Dict[str, BaseSkill]:
        """自动扫描skills文件夹，加载全部技能"""
        self.skill_map.clear()
        if not SKILL_DIR.exists():
            SKILL_DIR.mkdir()
            return self.skill_map

        for file in os.listdir(SKILL_DIR):
            if not file.endswith(".py") or file == "__init__.py":
                continue
            module_name = file[:-3]
            mod = importlib.import_module(f"skills.{module_name}")
            for attr in dir(mod):
                cls = getattr(mod, attr)
                if isinstance(cls, type) and issubclass(cls, BaseSkill) and cls != BaseSkill:
                    inst = cls()
                    self.skill_map[inst.get_meta().name] = inst
        return self.skill_map

    def get_skill(self, skill_name: str) -> Optional[BaseSkill]:
        return self.skill_map.get(skill_name)

    def get_all_schemas(self) -> list[dict]:
        """批量获取所有工具schema，传给LLM"""
        return [skill.get_tool_schema() for skill in self.skill_map.values()]