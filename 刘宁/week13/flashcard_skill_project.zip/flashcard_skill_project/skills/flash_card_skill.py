import json
import subprocess
from pathlib import Path
from openai import OpenAI
from harness.base_skill import BaseSkill, SkillMeta, SkillParam

# 路径常量
ROOT = Path(__file__).parent.parent
FLASHCARD_DATA = ROOT / "flash_card" / "data"
FLASHCARD_SCRIPT = ROOT / "flash_card" / "scripts" / "make_flashcard.py"
FLASHCARD_DATA.mkdir(exist_ok=True)

# 初始化LLM客户端（和main共用key）
llm_client = OpenAI(
    api_key="sk-9248b519f1d1449ea0c1e452a7dc7879",
    base_url="https://api.deepseek.com/v1"
)

class FlashCardSkill(BaseSkill):
    def get_meta(self) -> SkillMeta:
        return SkillMeta(
            name="flash_card_generator",
            description="生成英文单词闪卡HTML，包含音标、词性、释义、3组中英例句、近义词",
            params=[
                SkillParam(name="target_word", type="string", desc="需要生成闪卡的英文单词，小写", required=True)
            ]
        )

    def run(self, target_word: str):
        word = target_word.lower()
        json_path = FLASHCARD_DATA / f"{word}.json"

        # 调用LLM生成完整单词数据
        word_data = self._llm_generate_word_info(word)

        # 写入json文件
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(word_data, f, ensure_ascii=False, indent=2)

        # 运行脚本生成HTML
        cmd = ["python", str(FLASHCARD_SCRIPT), str(json_path)]
        subprocess.run(cmd, check=True, capture_output=True)
        html_path = ROOT / f"{word}.html"

        return {
            "word": word,
            "json_source": str(json_path),
            "flash_html": str(html_path),
            "msg": f"单词「{word}」闪卡生成完成，文件路径：{html_path}"
        }

    def _llm_generate_word_info(self, word: str) -> dict:
        prompt = f"""
你是英语词典，根据单词 {word} 输出严格JSON，无多余文字、无解释、无markdown。
JSON结构要求：
{{
  "word": "单词小写",
  "phonetic": "英美音标",
  "pos": "词性，多个用/分隔",
  "definition": "中文释义，多条分号隔开",
  "examples": [
    {{"en": "英文例句1", "zh": "中文翻译1"}},
    {{"en": "英文例句2", "zh": "中文翻译2"}},
    {{"en": "英文例句3", "zh": "中文翻译3"}}
  ],
  "synonyms": ["近义词1","近义词2","近义词3"]
}}
"""
        resp = llm_client.chat.completions.create(
            model="deepseek-chat",
            messages=[{"role":"user","content":prompt}],
            temperature=0.3
        )
        content = resp.choices[0].message.content.strip()
        return json.loads(content)