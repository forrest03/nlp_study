from openai import OpenAI
from harness.harness import SkillHarness

# 初始化LLM客户端（DeepSeek/OpenAI均可）
client = OpenAI(
    api_key="sk-9248b519f1d1449ea0c1e452a7dc7879",
    base_url="https://api.deepseek.com/v1"
)

if __name__ == "__main__":
    # 1. 初始化运行器，自动加载所有skills
    harness = SkillHarness()
    print("已加载技能列表：", list(harness.skills.keys()))

    # 2. 用户提问，完整执行工具调用链路
    user_input = "给我做 spider-man 的单词闪卡"
    result = harness.run_pipeline(user_input, client)

    # 3. 打印完整执行报告
    harness.print_report()