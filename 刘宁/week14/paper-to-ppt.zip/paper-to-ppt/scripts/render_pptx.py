# -*- coding: utf-8 -*-
import sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE

# 配色
COLOR_NAVY    = RGBColor(0x1a, 0x36, 0x5d)
COLOR_BLUE    = RGBColor(0x2b, 0x6c, 0xb0)
COLOR_BLUE2   = RGBColor(0x2c, 0x52, 0x82)
COLOR_GREEN   = RGBColor(0x38, 0xa1, 0x69)
COLOR_ORANGE  = RGBColor(0xdd, 0x6b, 0x20)
COLOR_PURPLE  = RGBColor(0x80, 0x50, 0xc0)
COLOR_GOLD    = RGBColor(0xd6, 0x9f, 0x00)
COLOR_GRAY    = RGBColor(0x71, 0x80, 0x96)
COLOR_DARK    = RGBColor(0x22, 0x22, 0x33)
COLOR_BODY    = RGBColor(0x33, 0x33, 0x44)

COLOR_LIGHT_BG     = RGBColor(0xf7, 0xfa, 0xfc)
COLOR_BLUE_BG      = RGBColor(0xeb, 0xf8, 0xff)
COLOR_GREEN_BG     = RGBColor(0xf0, 0xff, 0xf4)
COLOR_ORANGE_BG    = RGBColor(0xff, 0xfa, 0xf0)
COLOR_PURPLE_BG    = RGBColor(0xfa, 0xf5, 0xff)
COLOR_GOLD_BG      = RGBColor(0xff, 0xfb, 0xeb)
COLOR_RED_BG       = RGBColor(0xff, 0xf5, 0xf5)
COLOR_GRAY_BG      = RGBColor(0xed, 0xf2, 0xf7)
COLOR_WHITE        = RGBColor(0xff, 0xff, 0xff)
COLOR_HEADER       = COLOR_NAVY

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
BLANK = prs.slide_layouts[6]

CN = 'Microsoft YaHei'
EN = 'Calibri'

def rect(slide, x, y, w, h, fill, line=None, line_w=None):
    shp = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, x, y, w, h)
    shp.fill.solid()
    shp.fill.fore_color.rgb = fill
    if line is None:
        shp.line.fill.background()
    else:
        shp.line.color.rgb = line
        if line_w is not None:
            shp.line.width = line_w
    shp.shadow.inherit = False
    return shp

def round_rect(slide, x, y, w, h, fill, line=None, line_w=None):
    shp = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, h)
    shp.adjustments[0] = 0.08
    shp.fill.solid()
    shp.fill.fore_color.rgb = fill
    if line is None:
        shp.line.fill.background()
    else:
        shp.line.color.rgb = line
        if line_w is not None:
            shp.line.width = line_w
    shp.shadow.inherit = False
    return shp

def add_text(slide, x, y, w, h, text, *,
             size=14, bold=False, italic=False,
             color=COLOR_BODY, font=CN,
             align=PP_ALIGN.LEFT, anchor='top'):
    """Add a single-paragraph text box."""
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = Inches(0.05)
    tf.margin_right = Inches(0.05)
    tf.margin_top = Inches(0.02)
    tf.margin_bottom = Inches(0.02)
    p = tf.paragraphs[0]
    p.alignment = align
    r = p.add_run()
    r.text = text
    r.font.name = font
    r.font.size = Pt(size)
    r.font.bold = bold
    r.font.italic = italic
    r.font.color.rgb = color
    return tb

def add_paragraphs(slide, x, y, w, h, items, *,
                   size=14, color=COLOR_BODY, font=CN,
                   align=PP_ALIGN.LEFT, line_spacing=1.25,
                   space_after=4, bullet=False):
    """Add multi-paragraph text box.
    items: list of dicts or strings.
        string -> one paragraph plain text
        dict {text, bold, color, size, bullet, indent}
    """
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = Inches(0.05)
    tf.margin_right = Inches(0.05)
    tf.margin_top = Inches(0.02)
    tf.margin_bottom = Inches(0.02)
    for i, item in enumerate(items):
        if i == 0:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()
        if isinstance(item, str):
            spec = {'text': item}
        else:
            spec = dict(item)
        p.alignment = spec.get('align', align)
        p.line_spacing = spec.get('line_spacing', line_spacing)
        p.space_after = Pt(spec.get('space_after', space_after))
        if spec.get('indent'):
            p.level = spec['indent']
        text = spec['text']
        if spec.get('bullet', bullet) and not text.startswith(('•', '·', '-', '✓', '✗', '!', '①', '②', '③', '④')):
            text = '•  ' + text
        run = p.add_run()
        run.text = text
        run.font.name = spec.get('font', font)
        run.font.size = Pt(spec.get('size', size))
        run.font.bold = spec.get('bold', False)
        run.font.italic = spec.get('italic', False)
        run.font.color.rgb = spec.get('color', color)
    return tb

def add_header_bar(slide, title, subtitle=None):
    """Top title bar (dark navy) with a thin accent line below."""
    rect(slide, 0, 0, prs.slide_width, Inches(0.95), COLOR_NAVY)
    rect(slide, 0, Inches(0.95), prs.slide_width, Inches(0.08), COLOR_BLUE)
    add_text(slide, Inches(0.4), Inches(0.18), Inches(12.5), Inches(0.6),
             title, size=24, bold=True, color=COLOR_WHITE, font=CN)
    if subtitle:
        add_text(slide, Inches(0.4), Inches(0.55), Inches(12.5), Inches(0.4),
                 subtitle, size=12, color=RGBColor(0xa0, 0xae, 0xc0),
                 font=CN, italic=True)

def section_slide(part_label, title, subtitle):
    s = prs.slides.add_slide(BLANK)
    rect(s, 0, 0, prs.slide_width, prs.slide_height, COLOR_NAVY)
    rect(s, 0, Inches(2.6), prs.slide_width, Inches(0.06), COLOR_BLUE)
    add_text(s, Inches(0.5), Inches(2.05), Inches(12.3), Inches(0.6),
             part_label, size=22, color=RGBColor(0xa0, 0xae, 0xc0),
             font=EN, align=PP_ALIGN.CENTER)
    add_text(s, Inches(0.5), Inches(2.8), Inches(12.3), Inches(1.2),
             title, size=44, bold=True, color=COLOR_WHITE,
             font=CN, align=PP_ALIGN.CENTER)
    add_text(s, Inches(0.5), Inches(4.1), Inches(12.3), Inches(0.6),
             subtitle, size=18, color=RGBColor(0xc0, 0xcc, 0xe0),
             font=CN, align=PP_ALIGN.CENTER)
    return s

def side_bar(slide, x, y, w, h, color):
    """Thin colored left bar."""
    rect(slide, x, y, Inches(0.12), h, color)

def content_bg(slide):
    rect(slide, 0, Inches(1.03), prs.slide_width, Inches(6.47), COLOR_LIGHT_BG)

def page_number(slide, idx, total):
    add_text(slide, Inches(12.5), Inches(7.15), Inches(0.7), Inches(0.3),
             f'{idx} / {total}', size=9, color=COLOR_GRAY,
             font=EN, align=PP_ALIGN.RIGHT)

TOTAL_SLIDES_PLACEHOLDER = 30  # updated at end

# ====================================================================== #
# SLIDE 1: 封面
# ====================================================================== #
def slide_cover():
    s = prs.slides.add_slide(BLANK)
    # 蓝色渐变效果
    rect(s, 0, 0, prs.slide_width, prs.slide_height, COLOR_NAVY)
    rect(s, 0, Inches(5.5), prs.slide_width, Inches(2.0), COLOR_BLUE2)
    rect(s, 0, Inches(7.0), prs.slide_width, Inches(0.5), COLOR_BLUE)

    # 装饰
    rect(s, 0, Inches(0.5), prs.slide_width, Inches(0.04), COLOR_BLUE)
    rect(s, 0, Inches(7.0), prs.slide_width, Inches(0.04), COLOR_GREEN)

    add_text(s, Inches(0.5), Inches(0.8), Inches(12.3), Inches(0.4),
             '论文解读 Presentation', size=12, color=RGBColor(0xa0, 0xae, 0xc0),
             font=EN, align=PP_ALIGN.CENTER, italic=True)

    add_text(s, Inches(0.5), Inches(1.4), Inches(12.3), Inches(1.3),
             'PAST-Bench', size=60, bold=True, color=COLOR_WHITE,
             font=EN, align=PP_ALIGN.CENTER)

    add_text(s, Inches(0.5), Inches(2.7), Inches(12.3), Inches(0.8),
             '个人智能体递归自我改进基础能力的基准评测',
             size=28, bold=True, color=COLOR_WHITE, font=CN, align=PP_ALIGN.CENTER)

    add_text(s, Inches(0.5), Inches(3.6), Inches(12.3), Inches(0.5),
             'Benchmarking the Foundations of Recursive Self-Improvement in Personal Agents',
             size=14, color=RGBColor(0xc0, 0xcc, 0xe0), font=EN, italic=True,
             align=PP_ALIGN.CENTER)

    # 作者
    add_text(s, Inches(0.5), Inches(4.4), Inches(12.3), Inches(0.4),
             'Shuhan Xue*, Zixin Ding*, Yichen Shen*, Yinjie Wang, Zhenfei Yin,',
             size=13, color=COLOR_WHITE, font=EN, align=PP_ALIGN.CENTER)
    add_text(s, Inches(0.5), Inches(4.7), Inches(12.3), Inches(0.4),
             'Yingcheng Wu, Yuxin Chen, Mengdi Wang†, Ling Yang†',
             size=13, color=COLOR_WHITE, font=EN, align=PP_ALIGN.CENTER)

    # 元数据
    add_text(s, Inches(0.5), Inches(5.8), Inches(12.3), Inches(0.4),
             'arXiv: 2608.04003v1',
             size=14, color=COLOR_WHITE, font=EN, align=PP_ALIGN.CENTER, bold=True)
    add_text(s, Inches(0.5), Inches(6.2), Inches(12.3), Inches(0.4),
             '检索：2026 年 8 月 5 日',
             size=11, color=RGBColor(0xc0, 0xcc, 0xe0), font=CN, align=PP_ALIGN.CENTER)

# ====================================================================== #
# SLIDE 2: 目录
# ====================================================================== #
def slide_toc():
    s = prs.slides.add_slide(BLANK)
    add_header_bar(s, '今日内容', 'Table of Contents')
    content_bg(s)

    parts = [
        ('Part 1', '研究背景与动机', '为什么需要研究「递归自我改进」？', COLOR_BLUE),
        ('Part 2', 'PAST-Bench 核心设计', '首个支持保留经验归因的基准', COLOR_GREEN),
        ('Part 3', '四大评测能力维度', 'Memory · Procedural · Info · Update', COLOR_ORANGE),
        ('Part 4', '实验结果与分析', '7 模型 × 4 框架的系统性评测', COLOR_PURPLE),
        ('Part 5', 'Hermes+ 框架改进', '在智能体循环的五个阶段加入机制', COLOR_GOLD),
        ('Part 6', '结论与未来方向', '在线自我演化的研究展望', COLOR_NAVY),
    ]
    for i, (label, title, desc, color) in enumerate(parts):
        y = Inches(1.4) + i * Inches(0.9)
        # 左侧彩色块
        rect(s, Inches(1.0), y, Inches(1.6), Inches(0.75), color)
        add_text(s, Inches(1.0), y + Inches(0.2), Inches(1.6), Inches(0.4),
                 label, size=14, bold=True, color=COLOR_WHITE,
                 font=EN, align=PP_ALIGN.CENTER)
        # 标题
        add_text(s, Inches(2.8), y + Inches(0.05), Inches(4.5), Inches(0.4),
                 title, size=18, bold=True, color=COLOR_NAVY, font=CN)
        # 描述
        add_text(s, Inches(2.8), y + Inches(0.42), Inches(9.5), Inches(0.35),
                 desc, size=12, color=COLOR_GRAY, font=CN)

# ====================================================================== #
# SLIDE 3: Part 1 标题
# ====================================================================== #
section_slide('Part 1', '研究背景与动机', 'Background & Motivation')

# ====================================================================== #
# SLIDE 4: 什么是 RSI
# ====================================================================== #
def slide_what_is_rsi():
    s = prs.slides.add_slide(BLANK)
    add_header_bar(s, '什么是递归自我改进（RSI）？', 'Recursive Self-Improvement')
    content_bg(s)

    # 顶部核心定义
    round_rect(s, Inches(0.5), Inches(1.3), Inches(12.3), Inches(1.0), COLOR_BLUE_BG)
    side_bar(s, Inches(0.5), Inches(1.3), Inches(0.12), Inches(1.0), COLOR_BLUE)
    add_text(s, Inches(0.8), Inches(1.4), Inches(11.8), Inches(0.4),
             '核心定义', size=12, bold=True, color=COLOR_BLUE, font=CN)
    add_text(s, Inches(0.8), Inches(1.7), Inches(11.8), Inches(0.6),
             '递归自我改进（RSI）是指 AI 系统利用自身运行过程中产生的经验来提升未来能力的一种范式。其强形式涉及修改模型参数、学习算法或智能体架构；弱形式则通过复用交互经验来改变行为，无需修改模型本身。',
             size=14, color=COLOR_DARK, font=CN)

    # 强形式
    round_rect(s, Inches(0.5), Inches(2.5), Inches(6.0), Inches(2.4), COLOR_WHITE, COLOR_GRAY_BG, Pt(0.5))
    rect(s, Inches(0.5), Inches(2.5), Inches(6.0), Inches(0.45), COLOR_BLUE)
    add_text(s, Inches(0.7), Inches(2.55), Inches(5.6), Inches(0.4),
             '强形式 RSI', size=15, bold=True, color=COLOR_WHITE, font=CN)
    add_paragraphs(s, Inches(0.7), Inches(3.05), Inches(5.6), Inches(1.8), [
        {'text': '修改模型参数：通过自训练更新权重', 'size': 12, 'bullet': True, 'color': COLOR_DARK},
        {'text': '修改学习算法：改进优化器或目标函数', 'size': 12, 'bullet': True, 'color': COLOR_DARK},
        {'text': '修改智能体架构：重设计决策模块', 'size': 12, 'bullet': True, 'color': COLOR_DARK},
        {'text': '具有较高风险与不确定性，目前仍以研究为主', 'size': 12, 'bullet': True, 'color': COLOR_GRAY, 'italic': True},
    ])

    # 弱形式（在线自我演化）
    round_rect(s, Inches(6.85), Inches(2.5), Inches(6.0), Inches(2.4), COLOR_WHITE, COLOR_GRAY_BG, Pt(0.5))
    rect(s, Inches(6.85), Inches(2.5), Inches(6.0), Inches(0.45), COLOR_GREEN)
    add_text(s, Inches(7.05), Inches(2.55), Inches(5.6), Inches(0.4),
             '弱形式 RSI（本文关注）', size=15, bold=True, color=COLOR_WHITE, font=CN)
    add_paragraphs(s, Inches(7.05), Inches(3.05), Inches(5.6), Inches(1.8), [
        {'text': '保留用户偏好、任务历史、工具惯例、已学技能', 'size': 12, 'bullet': True, 'color': COLOR_DARK},
        {'text': '跨会话持续运行，无需修改模型权重', 'size': 12, 'bullet': True, 'color': COLOR_DARK},
        {'text': '已经出现在主流个人 AI 智能体中', 'size': 12, 'bullet': True, 'color': COLOR_DARK},
        {'text': '可作为强形式 RSI 的基础设施', 'size': 12, 'bullet': True, 'color': COLOR_GREEN, 'italic': True},
    ])

    # 底部示例
    round_rect(s, Inches(0.5), Inches(5.05), Inches(12.3), Inches(2.2), COLOR_LIGHT_BG, COLOR_GRAY_BG, Pt(0.5))
    rect(s, Inches(0.5), Inches(5.05), Inches(0.12), Inches(2.2), COLOR_GOLD)
    add_text(s, Inches(0.8), Inches(5.15), Inches(11.8), Inches(0.4),
             '代表性系统：个人 AI 智能体的「持久化」现状', size=14, bold=True, color=COLOR_NAVY, font=CN)
    add_paragraphs(s, Inches(0.8), Inches(5.55), Inches(11.8), Inches(1.6), [
        {'text': 'Hermes、OpenClaw 等智能体框架将持久化工作区、记忆、技能和工具执行作为一等运行时组件。',
         'size': 13, 'bullet': True, 'color': COLOR_DARK},
        {'text': 'Mem0、LangGraph 等记忆层系统提供可编辑记忆、交互衍生事实、时序知识图谱和程序性技能文件。',
         'size': 13, 'bullet': True, 'color': COLOR_DARK},
        {'text': '用户交互不再仅是瞬时上下文，而可以成为改变智能体未来行为的「经验」。',
         'size': 13, 'bullet': True, 'color': COLOR_DARK},
    ])

# ====================================================================== #
# SLIDE 5: 核心问题
# ====================================================================== #
def slide_core_question():
    s = prs.slides.add_slide(BLANK)
    add_header_bar(s, '核心问题：保留经验真的能改进智能体吗？', 'Core Research Question')
    content_bg(s)

    # 居中问题
    round_rect(s, Inches(1.5), Inches(1.4), Inches(10.3), Inches(1.3), COLOR_ORANGE_BG)
    rect(s, Inches(1.5), Inches(1.4), Inches(0.15), Inches(1.3), COLOR_ORANGE)
    add_text(s, Inches(1.8), Inches(1.55), Inches(9.8), Inches(0.5),
             'Q', size=24, bold=True, color=COLOR_ORANGE, font=EN, align=PP_ALIGN.CENTER)
    add_text(s, Inches(1.8), Inches(1.95), Inches(9.8), Inches(0.7),
             '在多会话、多任务的真实使用场景下，累积的经验是否真的能让个人 AI 智能体持续表现得更好？',
             size=16, bold=True, color=COLOR_ORANGE, font=CN, align=PP_ALIGN.CENTER)

    # 现状分析
    add_text(s, Inches(0.5), Inches(2.95), Inches(12.3), Inches(0.4),
             '现状：评测体系无法回答这个问题', size=15, bold=True, color=COLOR_NAVY, font=CN)
    add_paragraphs(s, Inches(0.5), Inches(3.35), Inches(12.3), Inches(1.8), [
        {'text': '交互式智能体基准（如 AgentBench、VisualWebArena、OSWorld 等）只在「全新会话」中给出一次性任务得分，将基础模型能力、提示工程、工具策略、保留经验混为一个数字。',
         'size': 13, 'bullet': True, 'color': COLOR_DARK},
        {'text': '记忆与技能基准（如 LongMemEval、LoCoMo、SkillsBench）孤立测试持久化的单一要素，缺乏匹配对照来区分「经验贡献」与「基础模型/运行时贡献」。',
         'size': 13, 'bullet': True, 'color': COLOR_DARK},
        {'text': '结果：业界普遍相信「持久化 = 智能体改进」，但缺少系统性验证，性能归因成为评测的关键缺口。',
         'size': 13, 'bullet': True, 'color': COLOR_ORANGE, 'italic': True},
    ])

    # 关键缺口
    round_rect(s, Inches(0.5), Inches(5.4), Inches(12.3), Inches(1.85), COLOR_RED_BG, COLOR_ORANGE, Pt(0.5))
    add_text(s, Inches(0.8), Inches(5.5), Inches(11.8), Inches(0.4),
             '性能归因问题', size=14, bold=True, color=COLOR_ORANGE, font=CN)
    add_paragraphs(s, Inches(0.8), Inches(5.9), Inches(11.8), Inches(1.3), [
        {'text': '如果后续会话的得分提高了，增益可能来自：保留的经验，或者基础模型、运行时、提示工程、检索捷径、任务难度波动、评分噪声。',
         'size': 13, 'color': COLOR_DARK},
        {'text': '现有基准无法区分这些来源，导致「智能体是否真的从经验中学习」成为一个悬而未决的问题。',
         'size': 13, 'color': COLOR_DARK, 'bold': True},
    ])

# ====================================================================== #
# SLIDE 6: 在线自我演化
# ====================================================================== #
def slide_online_evolution():
    s = prs.slides.add_slide(BLANK)
    add_header_bar(s, '「在线自我演化」：弱形式 RSI 的精确定义', 'Online Self-Evolution')
    content_bg(s)

    # 顶部定义
    round_rect(s, Inches(0.5), Inches(1.25), Inches(12.3), Inches(1.2), COLOR_GREEN_BG)
    rect(s, Inches(0.5), Inches(1.25), Inches(0.12), Inches(1.2), COLOR_GREEN)
    add_text(s, Inches(0.8), Inches(1.35), Inches(11.8), Inches(0.4),
             'Operational Definition', size=12, bold=True, color=COLOR_GREEN, font=EN)
    add_text(s, Inches(0.8), Inches(1.65), Inches(11.8), Inches(0.8),
             '在线自我演化（Online Self-Evolution）：个人智能体通过复用先前交互中累积的经验，改变其未来行为，'
             '而无需进行模型重训练、提示优化或长上下文适配。',
             size=15, color=COLOR_DARK, font=CN)

    # 三大要点
    add_text(s, Inches(0.5), Inches(2.65), Inches(12.3), Inches(0.4),
             '三个核心要点', size=15, bold=True, color=COLOR_NAVY, font=CN)

    points = [
        ('闭环', '识别有用经验 → 在当前会话之外保存 → 在相关时检索 → 正确应用 → 过时则修订',
         COLOR_BLUE),
        ('评测单位', '从「能否解决当前任务」转变为「能否在未来更好地服务同一用户」',
         COLOR_GREEN),
        ('基础设施', '保留持久偏好、复用先前工作流、修订陈旧信息，为强形式 RSI 提供行为与基础设施支撑',
         COLOR_ORANGE),
    ]
    for i, (label, content, color) in enumerate(points):
        y = Inches(3.1) + i * Inches(1.1)
        round_rect(s, Inches(0.5), y, Inches(12.3), Inches(1.0), COLOR_WHITE, COLOR_GRAY_BG, Pt(0.5))
        side_bar(s, Inches(0.5), y, Inches(0.12), Inches(1.0), color)
        add_text(s, Inches(0.8), y + Inches(0.1), Inches(2.0), Inches(0.8),
                 label, size=18, bold=True, color=color, font=CN,
                 anchor='middle')
        add_text(s, Inches(2.9), y + Inches(0.1), Inches(9.8), Inches(0.8),
                 content, size=13, color=COLOR_DARK, font=CN, anchor='middle')

    # 底部警示
    round_rect(s, Inches(0.5), Inches(6.4), Inches(12.3), Inches(0.85), COLOR_LIGHT_BG, COLOR_GRAY_BG, Pt(0.5))
    add_text(s, Inches(0.8), Inches(6.5), Inches(11.8), Inches(0.7),
             '⚠  注意：累积经验并不保证改进。智能体可能保存错误证据、检索无关记忆、复用脆弱程序，'
             '或将陈旧状态用于新任务。',
             size=12, color=COLOR_ORANGE, italic=True, font=CN, anchor='middle')

# ====================================================================== #
# SLIDE 7: Part 2 标题
# ====================================================================== #
section_slide('Part 2', 'PAST-Bench 核心设计', 'Benchmark Design')

# ====================================================================== #
# SLIDE 8: PAST-Bench 是什么
# ====================================================================== #
def slide_pastbench_intro():
    s = prs.slides.add_slide(BLANK)
    add_header_bar(s, 'PAST-Bench：一个支持性能归因的基准', 'PAST-Bench Overview')
    content_bg(s)

    # 顶部主标语
    round_rect(s, Inches(0.5), Inches(1.25), Inches(12.3), Inches(0.9), COLOR_BLUE_BG)
    add_text(s, Inches(0.5), Inches(1.3), Inches(12.3), Inches(0.8),
             'PAST-Bench = Performance-Attribution Self-evolution Test-Bench',
             size=18, bold=True, color=COLOR_NAVY, font=EN, align=PP_ALIGN.CENTER, anchor='middle')

    # 三大方法论创新
    add_text(s, Inches(0.5), Inches(2.3), Inches(12.3), Inches(0.4),
             '三大方法论创新', size=15, bold=True, color=COLOR_NAVY, font=CN)

    innovations = [
        ('① 任务族评测', '评测单位是「任务族」而非「单任务」。每个任务族由有序的全新会话 Episode 组成：'
         '较早 Episode 写入可复用经验，较晚 Episode 在新会话中测试是否被复用，配套对照 Episode 排除捷径解释。', COLOR_BLUE),
        ('② 匹配消融', '对每个评测 Episode 在持久化开启/关闭两种条件下做配对评分，两次运行共享同一提示、评分器、工具栈、随机种子，'
         '差距 Δ 直接归因于持久化层。', COLOR_GREEN),
        ('③ 机制证据', '除了任务得分 Δ，还报告 Mech 机制证据分：基于保存的工件与运行时遥测，判断改进是否走了预期的 write → retrieve → apply 通路。', COLOR_ORANGE),
    ]
    for i, (label, content, color) in enumerate(innovations):
        y = Inches(2.8) + i * Inches(1.4)
        round_rect(s, Inches(0.5), y, Inches(12.3), Inches(1.3), COLOR_WHITE, COLOR_GRAY_BG, Pt(0.5))
        rect(s, Inches(0.5), y, Inches(1.8), Inches(1.3), color)
        add_text(s, Inches(0.5), y + Inches(0.4), Inches(1.8), Inches(0.5),
                 label, size=14, bold=True, color=COLOR_WHITE, font=CN,
                 align=PP_ALIGN.CENTER, anchor='middle')
        add_text(s, Inches(2.5), y + Inches(0.15), Inches(10.2), Inches(1.1),
                 content, size=13, color=COLOR_DARK, font=CN, anchor='middle')

# ====================================================================== #
# SLIDE 9: 评测流程
# ====================================================================== #
def slide_eval_pipeline():
    s = prs.slides.add_slide(BLANK)
    add_header_bar(s, '评测流程：任务族与 Episode 角色', 'Evaluation Pipeline')
    content_bg(s)

    # 上部定义
    add_text(s, Inches(0.5), Inches(1.25), Inches(12.3), Inches(0.4),
             '核心思路：评测单位 = 任务族（Task Family），不是单任务',
             size=15, bold=True, color=COLOR_NAVY, font=CN)
    add_text(s, Inches(0.5), Inches(1.7), Inches(12.3), Inches(0.5),
             '一个任务族是一组有序的全新会话 Episode，它们共享潜在规则、可复用工件、待修正值或预置参考。'
             'Episode 之间严格清除 volatile 上下文，任何改进必须流经持久化底层。',
             size=12, color=COLOR_GRAY, font=CN)

    # 四种 Episode 角色
    add_text(s, Inches(0.5), Inches(2.45), Inches(12.3), Inches(0.4),
             '四种 Episode 角色', size=15, bold=True, color=COLOR_NAVY, font=CN)

    roles = [
        ('Cold', '首次接触', '在没有任何持久化状态下测试基线行为，'
                              '用于校准任务难度与得分上界', COLOR_GRAY, '灰色基线'),
        ('Learn', '学习', '把目标内容（条款、SOP、修正）写入持久化层：'
                          '记忆条目、技能文件、配置文件或会话历史', COLOR_BLUE, '写入阶段'),
        ('Evaluation', '评测', '在新会话中触发任务，但措辞已从提示中移除，'
                              '测试智能体是否主动复用保留状态', COLOR_GREEN, '复测阶段'),
        ('Control', '对照', '无保留对照、干扰对照、陈旧对照、错误机制对照，'
                           '排除捷径解释与作弊通路', COLOR_ORANGE, '排除阶段'),
    ]
    for i, (label, name, desc, color, tag) in enumerate(roles):
        y = Inches(2.9) + i * Inches(1.0)
        round_rect(s, Inches(0.5), y, Inches(12.3), Inches(0.9), COLOR_WHITE, COLOR_GRAY_BG, Pt(0.5))
        # 左侧色块
        rect(s, Inches(0.5), y, Inches(1.5), Inches(0.9), color)
        add_text(s, Inches(0.5), y + Inches(0.25), Inches(1.5), Inches(0.4),
                 label, size=14, bold=True, color=COLOR_WHITE, font=EN,
                 align=PP_ALIGN.CENTER)
        # 中文名
        add_text(s, Inches(2.2), y + Inches(0.1), Inches(2.0), Inches(0.4),
                 name, size=15, bold=True, color=color, font=CN)
        # 描述
        add_text(s, Inches(2.2), y + Inches(0.45), Inches(8.0), Inches(0.45),
                 desc, size=11, color=COLOR_DARK, font=CN)
        # 标签
        add_text(s, Inches(10.5), y + Inches(0.25), Inches(2.2), Inches(0.4),
                 tag, size=12, color=COLOR_GRAY, italic=True, font=CN,
                 align=PP_ALIGN.RIGHT)

# ====================================================================== #
# SLIDE 10: 规模与覆盖
# ====================================================================== #
def slide_scale():
    s = prs.slides.add_slide(BLANK)
    add_header_bar(s, 'PAST-Bench 规模与能力覆盖', 'Scale & Capability Coverage')
    content_bg(s)

    # 三个统计数字
    stats = [('26', '任务场景', 'scenario', COLOR_NAVY),
             ('204', '评测 Episode', 'episodes', COLOR_BLUE),
             ('4', '核心能力维度', 'capabilities', COLOR_GREEN)]
    for i, (num, label, en, color) in enumerate(stats):
        x = Inches(0.8) + i * Inches(4.2)
        rect(s, x, Inches(1.3), Inches(3.8), Inches(1.9), color)
        add_text(s, x, Inches(1.4), Inches(3.8), Inches(1.1),
                 num, size=60, bold=True, color=COLOR_WHITE, font=EN, align=PP_ALIGN.CENTER)
        add_text(s, x, Inches(2.3), Inches(3.8), Inches(0.5),
                 label, size=15, bold=True, color=COLOR_WHITE, font=CN, align=PP_ALIGN.CENTER)
        add_text(s, x, Inches(2.7), Inches(3.8), Inches(0.4),
                 en, size=11, color=RGBColor(0xc0, 0xcc, 0xe0), font=EN, align=PP_ALIGN.CENTER, italic=True)

    # 四大能力详细分布
    add_text(s, Inches(0.5), Inches(3.5), Inches(12.3), Inches(0.4),
             '四大能力维度的具体分布', size=15, bold=True, color=COLOR_NAVY, font=CN)
    caps = [
        ('Memory', '5 / 41', '陈述性记忆：偏好、约束、单行策略、例外、先前案例', COLOR_BLUE2),
        ('Procedural Reuse', '8 / 64', '程序性复用：SOP、剧本、构建/部署流水线、事件分流流程', COLOR_BLUE),
        ('Information Gathering', '6 / 48', '信息收集：在噪声上下文中主动检索已预置的参考', COLOR_GREEN),
        ('Update', '7 / 51', '更新：第二次权威写入覆盖第一次，不泄漏旧值', COLOR_ORANGE),
    ]
    for i, (name, count, desc, color) in enumerate(caps):
        y = Inches(4.0) + i * Inches(0.75)
        round_rect(s, Inches(0.5), y, Inches(12.3), Inches(0.7), COLOR_WHITE, COLOR_GRAY_BG, Pt(0.5))
        rect(s, Inches(0.5), y, Inches(2.8), Inches(0.7), color)
        add_text(s, Inches(0.5), y + Inches(0.15), Inches(2.8), Inches(0.4),
                 name, size=13, bold=True, color=COLOR_WHITE, font=EN, align=PP_ALIGN.CENTER)
        add_text(s, Inches(0.5), y + Inches(0.45), Inches(2.8), Inches(0.3),
                 f'{count} 族/集', size=10, color=COLOR_WHITE, font=CN, align=PP_ALIGN.CENTER)
        add_text(s, Inches(3.5), y + Inches(0.15), Inches(9.2), Inches(0.5),
                 desc, size=12, color=COLOR_DARK, font=CN, anchor='middle')

# ====================================================================== #
# SLIDE 11: Part 3 标题
# ====================================================================== #
section_slide('Part 3', '四大评测能力维度', 'Four Core Capabilities')

# ====================================================================== #
# 4 个能力维度共用模板
# ====================================================================== #
def slide_capability(num, name, en, target, isolation, scenario, color, related=None):
    s = prs.slides.add_slide(BLANK)
    add_header_bar(s, f'能力 {num}：{name}（{en}）', f'Capability {num}: {en}')
    content_bg(s)

    # 顶部测试目标
    round_rect(s, Inches(0.5), Inches(1.25), Inches(12.3), Inches(1.1), COLOR_LIGHT_BG, color, Pt(1.5))
    add_text(s, Inches(0.8), Inches(1.35), Inches(2.0), Inches(0.4),
             '测试目标', size=13, bold=True, color=color, font=CN)
    add_text(s, Inches(0.8), Inches(1.75), Inches(11.7), Inches(0.6),
             target, size=14, color=COLOR_DARK, font=CN, anchor='middle')

    # 隔离路径
    round_rect(s, Inches(0.5), Inches(2.55), Inches(6.0), Inches(2.0), COLOR_WHITE, COLOR_GRAY_BG, Pt(0.5))
    rect(s, Inches(0.5), Inches(2.55), Inches(6.0), Inches(0.4), color)
    add_text(s, Inches(0.7), Inches(2.6), Inches(5.6), Inches(0.35),
             '隔离路径', size=13, bold=True, color=COLOR_WHITE, font=CN)
    add_text(s, Inches(0.7), Inches(3.05), Inches(5.6), Inches(1.45),
             isolation, size=12, color=COLOR_DARK, font=CN)

    # 典型场景
    round_rect(s, Inches(6.85), Inches(2.55), Inches(6.0), Inches(2.0), COLOR_WHITE, COLOR_GRAY_BG, Pt(0.5))
    rect(s, Inches(6.85), Inches(2.55), Inches(6.0), Inches(0.4), color)
    add_text(s, Inches(7.05), Inches(2.6), Inches(5.6), Inches(0.35),
             '典型场景', size=13, bold=True, color=COLOR_WHITE, font=CN)
    add_text(s, Inches(7.05), Inches(3.05), Inches(5.6), Inches(1.45),
             scenario, size=12, color=COLOR_DARK, font=CN)

    # 评测要点
    add_text(s, Inches(0.5), Inches(4.75), Inches(12.3), Inches(0.4),
             '评测要点', size=15, bold=True, color=COLOR_NAVY, font=CN)
    eval_pts = {
        1: [
            '评测 Episode 成功条件：智能体在全新会话中恢复并应用该条款，且触发措辞已从提示中移除。',
            '条款一旦写入不再修订，更新行为留给能力 4 评估。',
            '测试的是「声明性记忆」的查找与应用能力。',
        ],
        2: [
            '评测 Episode 成功条件：智能体按正确顺序、调用正确工具完成多步工作流。',
            '顺序错误、跳过步骤、错误工具替换均判失败。',
            '程序修订留给能力 4 评估，本能力隔离首次程序形成。',
        ],
        3: [
            '评测 Episode 成功条件：智能体在噪声上下文中主动调用持久化通道检索答案。',
            '每个族植入「通用默认值」：若不检索直接答，会得到 plausible 但错误的答案。',
            '测试的不是「保留」，而是「何时查询」。',
        ],
        4: [
            '评测 Episode 成功条件：新值被使用，旧值不泄漏。',
            '覆盖场景：事实修正、全局/作用域规则迁移、临时例外过期、SOP 补丁、recall-then-modify。',
            '测试的是「写覆盖写」的持久化能力。',
        ],
    }
    items = eval_pts[num]
    add_paragraphs(s, Inches(0.5), Inches(5.2), Inches(12.3), Inches(1.5),
                   [{'text': it, 'size': 12, 'color': COLOR_DARK, 'bullet': True} for it in items])

    if related:
        add_text(s, Inches(0.5), Inches(6.85), Inches(12.3), Inches(0.4),
                 related, size=12, color=color, italic=True, font=CN)

# ====================================================================== #
# SLIDE 16: Part 4 标题
# ====================================================================== #
section_slide('Part 4', '实验结果与分析', 'Experimental Results')

# ====================================================================== #
# 表格辅助函数
# ====================================================================== #
def add_table(slide, x, y, w, h, header, rows, col_widths, header_color=COLOR_NAVY,
              row_colors=None, highlight_rows=None, highlight_color=None,
              font_size=12, header_size=12):
    """Draw a simple table using shapes (so we can color cells)."""
    col_count = len(header)
    total_w = sum(col_widths)
    # 计算每列的实际像素宽度
    real_widths = [int(w * cw / total_w) for cw in col_widths]
    # 头部
    cur_x = x
    header_h = Inches(0.5)
    for i, head in enumerate(header):
        rect(slide, cur_x, y, real_widths[i], header_h, header_color)
        add_text(slide, cur_x, y, real_widths[i], header_h,
                 head, size=header_size, bold=True, color=COLOR_WHITE,
                 font=CN, align=PP_ALIGN.CENTER, anchor='middle')
        cur_x += real_widths[i]
    # 数据行
    row_h = (h - header_h) // max(1, len(rows))
    for ri, row in enumerate(rows):
        cur_x = x
        ry = y + header_h + ri * row_h
        bg = COLOR_WHITE
        if highlight_rows and ri in highlight_rows:
            bg = highlight_color or RGBColor(0xe6, 0xff, 0xf0)
        elif row_colors:
            bg = row_colors[ri % len(row_colors)]
        for ci, cell in enumerate(row):
            rect(slide, cur_x, ry, real_widths[ci], row_h, bg, COLOR_GRAY_BG, Pt(0.25))
            # bold 第一列
            bold = (ci == 0) or (highlight_rows and ri in highlight_rows)
            color = COLOR_DARK
            # 数字列高亮
            if isinstance(cell, str) and (cell.startswith('+') and len(cell) < 8):
                color = COLOR_GREEN
                bold = True
            add_text(slide, cur_x, ry, real_widths[ci], row_h,
                     str(cell), size=font_size, bold=bold, color=color,
                     font=CN, align=PP_ALIGN.CENTER, anchor='middle')
            cur_x += real_widths[ci]

# ====================================================================== #
# SLIDE 17: 模型对比
# ====================================================================== #
def slide_model_comparison():
    s = prs.slides.add_slide(BLANK)
    add_header_bar(s, '实验结果 ①：固定 Hermes 框架，对比 7 个基础模型', 'Model Comparison')
    content_bg(s)

    # 表格
    add_text(s, Inches(0.5), Inches(1.2), Inches(12.3), Inches(0.4),
             '表 2：Hermes 框架下不同基础模型的 Overall Δ 与 Mech',
             size=13, bold=True, color=COLOR_NAVY, font=CN)

    header = ['基础模型', 'Memory Δ', 'Procedural Δ', 'Info. Δ', 'Update Δ', 'Overall Δ', 'Mech']
    rows = [
        ('GLM-5.1', '+0.23', '+0.09', '+0.11', '+0.36', '+0.20', '0.70'),
        ('Kimi K2.6', '+0.33', '+0.03', '+0.05', '+0.27', '+0.17', '0.72'),
        ('DeepSeek-V4-Pro', '+0.33', '+0.12', '+0.06', '+0.18', '+0.17', '0.71'),
        ('MiniMax-M2.7', '+0.26', '+0.05', '+0.09', '+0.12', '+0.13', '0.64'),
        ('GPT-5.4', '+0.37', '+0.19', '+0.07', '+0.34', '+0.24', '0.80'),
        ('Claude Sonnet 4.6', '+0.32', '+0.10', '+0.10', '+0.29', '+0.20', '0.76'),
        ('Claude Opus 4.6', '+0.26', '+0.14', '+0.06', '+0.28', '+0.19', '0.70'),
    ]
    add_table(s, Inches(0.5), Inches(1.7), Inches(12.3), Inches(2.8),
              header, rows, [3.2, 1.5, 1.8, 1.3, 1.5, 1.5, 1.5],
              row_colors=[COLOR_LIGHT_BG, COLOR_WHITE],
              font_size=12)

    # 解读
    round_rect(s, Inches(0.5), Inches(4.7), Inches(12.3), Inches(2.6), COLOR_GREEN_BG)
    rect(s, Inches(0.5), Inches(4.7), Inches(0.12), Inches(2.6), COLOR_GREEN)
    add_text(s, Inches(0.8), Inches(4.8), Inches(11.8), Inches(0.4),
             '关键发现', size=14, bold=True, color=COLOR_GREEN, font=CN)
    add_paragraphs(s, Inches(0.8), Inches(5.2), Inches(11.8), Inches(2.0), [
        {'text': '所有 7 个模型均从持久化中获益（Overall Δ 从 +0.13 到 +0.24），说明运行时持久化价值跨架构稳健存在。',
         'size': 12, 'color': COLOR_DARK},
        {'text': '但各模型将增益集中在哪些能力上差异显著：GPT-5.4 在 Memory（38%）与 Update（35%）之间较为均衡；GLM-5.1 将近一半放在 Update（46%）；Kimi K2.6 将近一半放在 Memory（49%）。',
         'size': 12, 'color': COLOR_DARK},
        {'text': '模型已擅长的能力，也是保留经验帮助最大的地方。单一 Overall Δ 会「说错故事」，四能力分解才揭示模型特定优势。',
         'size': 12, 'color': COLOR_GREEN, 'bold': True},
    ])

# ====================================================================== #
# SLIDE 18: 框架对比
# ====================================================================== #
def slide_framework_comparison():
    s = prs.slides.add_slide(BLANK)
    add_header_bar(s, '实验结果 ②：固定 MiniMax-M2.7，对比 4 个智能体框架', 'Framework Comparison')
    content_bg(s)

    add_text(s, Inches(0.5), Inches(1.2), Inches(12.3), Inches(0.4),
             '表 3：MiniMax-M2.7 固定下各智能体框架的 Overall Δ 与 Mech',
             size=13, bold=True, color=COLOR_NAVY, font=CN)

    header = ['智能体框架', 'Memory Δ', 'Procedural Δ', 'Info. Δ', 'Update Δ', 'Overall Δ', 'Mech']
    rows = [
        ('nanobot', '+0.06', '−0.06', '+0.13', '+0.37', '+0.13', '0.57'),
        ('ZeroClaw', '+0.29', '−0.04', '+0.08', '+0.15', '+0.12', '0.55'),
        ('Agent-Zero', '−0.27', '+0.11', '−0.01', '−0.13', '−0.08', '0.39'),
        ('Hermes', '+0.26', '+0.05', '+0.09', '+0.12', '+0.13', '0.64'),
        ('Hermes+（本文）', '+0.27', '−0.02', '+0.12', '+0.24', '+0.15', '0.73'),
    ]
    add_table(s, Inches(0.5), Inches(1.7), Inches(12.3), Inches(2.6),
              header, rows, [2.8, 1.5, 1.7, 1.3, 1.5, 1.7, 1.5],
              row_colors=[COLOR_LIGHT_BG, COLOR_WHITE],
              highlight_rows={4}, highlight_color=RGBColor(0xe6, 0xff, 0xf0),
              font_size=12)

    # 解读
    round_rect(s, Inches(0.5), Inches(4.5), Inches(12.3), Inches(2.8), COLOR_ORANGE_BG)
    rect(s, Inches(0.5), Inches(4.5), Inches(0.12), Inches(2.8), COLOR_ORANGE)
    add_text(s, Inches(0.8), Inches(4.6), Inches(11.8), Inches(0.4),
             '关键发现', size=14, bold=True, color=COLOR_ORANGE, font=CN)
    add_paragraphs(s, Inches(0.8), Inches(5.0), Inches(11.8), Inches(2.2), [
        {'text': 'ZeroClaw 提升 Memory（52%）但 Procedural 退步；nanobot 将 60% 放在 Update 但 Memory 几乎无改进；Agent-Zero 在四项能力中三项退步。',
         'size': 12, 'color': COLOR_DARK},
        {'text': 'Hermes 是唯一四项能力均正向移动的基线框架；Hermes+ 在 Update 上大幅领先（+0.24 vs Hermes +0.12），同时保持 Memory 与 Info 的优势。',
         'size': 12, 'color': COLOR_DARK},
        {'text': '机制证据得分随此形态变化：nanobot 与 Hermes 均达 Δ=+0.13，但 nanobot 仅靠单一能力且无一致 write→read 轨迹，Mech 降至 0.57；Hermes 为 0.64。',
         'size': 12, 'color': COLOR_ORANGE, 'bold': True},
    ])

# ====================================================================== #
# SLIDE 19: 关键发现 1 - 能力分布不均
# ====================================================================== #
def slide_finding_1():
    s = prs.slides.add_slide(BLANK)
    add_header_bar(s, '关键发现 ①：能力分布不均', 'Finding 1: Capability Distribution')
    content_bg(s)

    # 顶部主标语
    round_rect(s, Inches(0.5), Inches(1.25), Inches(12.3), Inches(1.2), COLOR_BLUE_BG)
    rect(s, Inches(0.5), Inches(1.25), Inches(0.12), Inches(1.2), COLOR_BLUE)
    add_text(s, Inches(0.8), Inches(1.35), Inches(11.8), Inches(0.4),
             '模型特定现象', size=12, bold=True, color=COLOR_BLUE, font=CN)
    add_text(s, Inches(0.8), Inches(1.65), Inches(11.8), Inches(0.8),
             '模型已擅长的能力，也是保留经验帮助最大的地方。单一 Overall Δ 报告值会「说错故事」，'
             '因为它掩盖了不同能力维度上的实际增益分布。',
             size=14, color=COLOR_DARK, font=CN, anchor='middle')

    # 各模型分布
    add_text(s, Inches(0.5), Inches(2.65), Inches(12.3), Inches(0.4),
             '各模型的 Δ 能力分布', size=15, bold=True, color=COLOR_NAVY, font=CN)

    distributions = [
        ('GPT-5.4', '均衡分布', '38%', '35%', '在 Memory 与 Update 上分布均衡，Procedural 与 Info 较弱',
         COLOR_GREEN),
        ('GLM-5.1', '集中在 Update', '29%', '46%', '近一半 movement 集中在 Update 能力',
         COLOR_ORANGE),
        ('Kimi K2.6', '集中在 Memory', '49%', '40%', '近一半 movement 集中在 Memory 能力',
         COLOR_BLUE),
        ('DeepSeek / Claude', '介于两者之间', '38-40%', '26-36%', 'Memory 与 Update 都有显著贡献',
         COLOR_PURPLE),
    ]
    for i, (model, pattern, mem, upd, desc, color) in enumerate(distributions):
        y = Inches(3.1) + i * Inches(0.95)
        round_rect(s, Inches(0.5), y, Inches(12.3), Inches(0.85), COLOR_WHITE, COLOR_GRAY_BG, Pt(0.5))
        rect(s, Inches(0.5), y, Inches(2.5), Inches(0.85), color)
        add_text(s, Inches(0.5), y + Inches(0.2), Inches(2.5), Inches(0.45),
                 model, size=12, bold=True, color=COLOR_WHITE, font=EN,
                 align=PP_ALIGN.CENTER, anchor='middle')
        add_text(s, Inches(3.2), y + Inches(0.1), Inches(3.0), Inches(0.4),
                 pattern, size=13, bold=True, color=color, font=CN)
        add_text(s, Inches(6.5), y + Inches(0.1), Inches(1.5), Inches(0.4),
                 f'Memory {mem}', size=12, color=COLOR_BLUE, font=CN, align=PP_ALIGN.CENTER)
        add_text(s, Inches(8.0), y + Inches(0.1), Inches(1.5), Inches(0.4),
                 f'Update {upd}', size=12, color=COLOR_ORANGE, font=CN, align=PP_ALIGN.CENTER)
        add_text(s, Inches(9.6), y + Inches(0.1), Inches(3.2), Inches(0.7),
                 desc, size=11, color=COLOR_GRAY, font=CN, anchor='middle')

# ====================================================================== #
# SLIDE 20: 关键发现 2 - 相同 Δ 不同机制
# ====================================================================== #
def slide_finding_2():
    s = prs.slides.add_slide(BLANK)
    add_header_bar(s, '关键发现 ②：相同 Δ，机制迥异', 'Finding 2: Same Δ, Different Mechanism')
    content_bg(s)

    # 顶部对比卡
    # Hermes
    round_rect(s, Inches(0.5), Inches(1.25), Inches(6.0), Inches(2.6), COLOR_GREEN_BG)
    rect(s, Inches(0.5), Inches(1.25), Inches(6.0), Inches(0.5), COLOR_GREEN)
    add_text(s, Inches(0.7), Inches(1.32), Inches(5.6), Inches(0.4),
             'Hermes', size=15, bold=True, color=COLOR_WHITE, font=EN)
    add_text(s, Inches(0.7), Inches(1.8), Inches(5.6), Inches(0.4),
             'Δ = +0.13 | Mech = 0.64', size=18, bold=True, color=COLOR_GREEN, font=EN)
    add_paragraphs(s, Inches(0.7), Inches(2.3), Inches(5.6), Inches(1.5), [
        {'text': '四项能力均正向移动', 'size': 12, 'bullet': True, 'color': COLOR_DARK},
        {'text': '机制证据一致：write→retrieve→apply 通路完整', 'size': 12, 'bullet': True, 'color': COLOR_DARK},
        {'text': 'Memory Δ +0.26, Update Δ +0.12, Info Δ +0.09, Procedural Δ +0.05', 'size': 11, 'color': COLOR_GRAY, 'italic': True},
    ])

    # nanobot
    round_rect(s, Inches(6.85), Inches(1.25), Inches(6.0), Inches(2.6), COLOR_ORANGE_BG)
    rect(s, Inches(6.85), Inches(1.25), Inches(6.0), Inches(0.5), COLOR_ORANGE)
    add_text(s, Inches(7.05), Inches(1.32), Inches(5.6), Inches(0.4),
             'nanobot', size=15, bold=True, color=COLOR_WHITE, font=EN)
    add_text(s, Inches(7.05), Inches(1.8), Inches(5.6), Inches(0.4),
             'Δ = +0.13 | Mech = 0.57', size=18, bold=True, color=COLOR_ORANGE, font=EN)
    add_paragraphs(s, Inches(7.05), Inches(2.3), Inches(5.6), Inches(1.5), [
        {'text': '仅 Update 能力贡献（Δ +0.37，占 59%）', 'size': 12, 'bullet': True, 'color': COLOR_DARK},
        {'text': '无一致的 write→read 轨迹，机制证据不足', 'size': 12, 'bullet': True, 'color': COLOR_DARK},
        {'text': 'Memory Δ +0.06, Update Δ +0.37, Info Δ +0.13, Procedural Δ −0.06', 'size': 11, 'color': COLOR_GRAY, 'italic': True},
    ])

    # 核心警示
    round_rect(s, Inches(0.5), Inches(4.0), Inches(12.3), Inches(0.9), COLOR_RED_BG, COLOR_ORANGE, Pt(0.5))
    add_text(s, Inches(0.8), Inches(4.1), Inches(11.8), Inches(0.7),
             '⚠  相同的 headline Δ = +0.13，背后可能是两种完全不同的实现路径！',
             size=15, bold=True, color=COLOR_ORANGE, font=CN, anchor='middle', align=PP_ALIGN.CENTER)

    # 方法论启示
    add_text(s, Inches(0.5), Inches(5.1), Inches(12.3), Inches(0.4),
             '方法论启示', size=15, bold=True, color=COLOR_NAVY, font=CN)
    add_paragraphs(s, Inches(0.5), Inches(5.5), Inches(12.3), Inches(1.8), [
        {'text': '仅报告 task score / Δ 是远远不够的：相同的 Δ 数值可能掩盖截然不同的内部机制。',
         'size': 13, 'bullet': True, 'color': COLOR_DARK},
        {'text': '必须同时报告 Mech 机制证据：基于保存的工件与运行时遥测，判断改进是否走了预期的持久化通路。',
         'size': 13, 'bullet': True, 'color': COLOR_DARK},
        {'text': '否则我们无法判断「智能体真的从经验中学习」还是「通过其他捷径获得表面提升」。',
         'size': 13, 'bullet': True, 'color': COLOR_GREEN, 'bold': True},
    ])

# ====================================================================== #
# SLIDE 21: Part 5 标题
# ====================================================================== #
section_slide('Part 5', 'Hermes+ 框架改进', 'Diagnosis-Driven Framework')

# ====================================================================== #
# SLIDE 22: 五大失败类别
# ====================================================================== #
def slide_failure_categories():
    s = prs.slides.add_slide(BLANK)
    add_header_bar(s, '诊断驱动设计：五大失败类别，五项机制', 'Diagnosis-Driven Design')
    content_bg(s)

    # 顶部介绍
    add_text(s, Inches(0.5), Inches(1.25), Inches(12.3), Inches(0.4),
             '低增益和不均匀增益的轨迹落入五个互不重叠的失败类别',
             size=14, bold=True, color=COLOR_NAVY, font=CN)
    add_text(s, Inches(0.5), Inches(1.7), Inches(12.3), Inches(0.5),
             '我们检查了 PAST-Bench 上的失败轨迹，将失败定位到智能体循环的五个具体阶段，每一类对应一项针对性机制，'
             '可独立启用或消融。',
             size=12, color=COLOR_GRAY, font=CN)

    # 五项机制概览
    mechs = [
        ('E1', 'Plan', '规划时咨询', '在起草 risky 动作前先查阅持久状态', COLOR_BLUE, '跨能力'),
        ('E2', 'Render', '记忆绑定渲染', '将记忆存为 typed binding，仅暴露当前值', COLOR_GREEN, 'Memory'),
        ('E3', 'Route', '技能生命周期', '将程序保存为可排序、可补丁的技能', COLOR_ORANGE, 'Procedural'),
        ('E4', 'Gate', '检索门控', 'recall-dependent 任务前必须先检索', COLOR_PURPLE, 'Info Gathering'),
        ('E5', 'Close', '回合结束 Flush', '同步覆盖写入，确保下一会话读到新值', COLOR_GOLD, 'Update'),
    ]
    for i, (code, en, cn, desc, color, target) in enumerate(mechs):
        y = Inches(2.4) + i * Inches(0.95)
        round_rect(s, Inches(0.5), y, Inches(12.3), Inches(0.85), COLOR_WHITE, COLOR_GRAY_BG, Pt(0.5))
        # 左侧色块
        rect(s, Inches(0.5), y, Inches(1.2), Inches(0.85), color)
        add_text(s, Inches(0.5), y + Inches(0.2), Inches(1.2), Inches(0.45),
                 code, size=18, bold=True, color=COLOR_WHITE, font=EN, align=PP_ALIGN.CENTER)
        # 英文
        add_text(s, Inches(1.9), y + Inches(0.1), Inches(1.8), Inches(0.4),
                 en, size=14, bold=True, color=color, font=EN)
        # 中文
        add_text(s, Inches(3.7), y + Inches(0.1), Inches(2.5), Inches(0.4),
                 cn, size=14, bold=True, color=COLOR_DARK, font=CN)
        # 描述
        add_text(s, Inches(6.2), y + Inches(0.1), Inches(5.0), Inches(0.7),
                 desc, size=11, color=COLOR_GRAY, font=CN, anchor='middle')
        # 目标能力
        add_text(s, Inches(11.3), y + Inches(0.15), Inches(1.4), Inches(0.6),
                 f'目标：{target}', size=10, color=color, italic=True, font=CN,
                 align=PP_ALIGN.CENTER, anchor='middle')

# ====================================================================== #
# SLIDE 23: 详细机制 E1-E4
# ====================================================================== #
def slide_mechanism_details():
    s = prs.slides.add_slide(BLANK)
    add_header_bar(s, 'Hermes+ 五项机制详解（上）', 'Hermes+ Mechanism Details (1/2)')
    content_bg(s)

    mechs = [
        ('E1 Plan', '规划时咨询', COLOR_BLUE,
         '问题：即使相关状态已正确写入并可检索，智能体的计划仍经常在未先查阅的情况下被起草，导致 draft 动作覆盖了正确存储的状态。',
         '干预：在规划阶段加入 consultation check。在起草任何 risky 或 recall-dependent 动作前，必须先查阅运行时当前暴露的持久状态，并以之为条件。'),
        ('E2 Render', '记忆绑定渲染', COLOR_GREEN,
         '问题：当前与陈旧记忆可能混在一起，作用域隐式，下一会话难以找到清晰的有效条款。',
         '干预：将记忆存为 typed binding（含类型、作用域、实体、当前值、被取代值、过期时间），渲染时仅暴露 in-scope 的当前 binding，抑制被取代条目。'),
        ('E3 Route', '技能生命周期', COLOR_ORANGE,
         '问题：学习 Episode 中已解出工作流，但 SOP 停留在 transcript 文本或 near-duplicate notes 中，后续 Episode 没有可排序技能可调用。',
         '干预：将程序保存为带适用条件 + 有序步骤的可排序、可补丁技能；按查询相关性排序，变化时 patch 最近似现有技能。'),
        ('E4 Gate', '检索门控', COLOR_PURPLE,
         '问题：在噪声提示下，智能体可能在调用持久化通道前就从可见上下文作答、拒绝猜测或采取不可逆行动。',
         '干预：当任务依赖先前状态且尚未发生持久化读取时，阻止 draft 答案，要求从相关通道读取。'),
    ]
    for i, (label, cn_name, color, problem, fix) in enumerate(mechs):
        col = i % 2
        row = i // 2
        x = Inches(0.5) + col * Inches(6.3)
        y = Inches(1.25) + row * Inches(3.0)
        w = Inches(6.0)
        h = Inches(2.85)
        round_rect(s, x, y, w, h, COLOR_WHITE, COLOR_GRAY_BG, Pt(0.5))
        rect(s, x, y, w, Inches(0.5), color)
        add_text(s, x + Inches(0.2), y + Inches(0.08), w - Inches(0.4), Inches(0.4),
                 label, size=14, bold=True, color=COLOR_WHITE, font=EN)
        add_text(s, x + Inches(2.0), y + Inches(0.08), w - Inches(2.0), Inches(0.4),
                 cn_name, size=13, bold=True, color=COLOR_WHITE, font=CN, align=PP_ALIGN.RIGHT)
        add_paragraphs(s, x + Inches(0.2), y + Inches(0.6), w - Inches(0.4), h - Inches(0.7), [
            {'text': '问题：' + problem, 'size': 10, 'color': COLOR_ORANGE},
            {'text': '干预：' + fix, 'size': 10, 'color': COLOR_DARK},
        ], space_after=2)

# ====================================================================== #
# SLIDE 24: E5
# ====================================================================== #
def slide_mechanism_e5():
    s = prs.slides.add_slide(BLANK)
    add_header_bar(s, 'Hermes+ 五项机制详解（下）', 'Hermes+ Mechanism Details (2/2)')
    content_bg(s)

    # E5 完整卡片
    round_rect(s, Inches(0.5), Inches(1.25), Inches(12.3), Inches(4.5), COLOR_WHITE, COLOR_GOLD, Pt(1.5))
    rect(s, Inches(0.5), Inches(1.25), Inches(12.3), Inches(0.6), COLOR_GOLD)
    add_text(s, Inches(0.7), Inches(1.32), Inches(11.9), Inches(0.45),
             'E5 Close — 回合结束 Flush', size=16, bold=True, color=COLOR_WHITE, font=EN)
    add_text(s, Inches(0.7), Inches(1.32), Inches(11.9), Inches(0.45),
             '目标能力：Update', size=12, color=COLOR_WHITE, font=CN, align=PP_ALIGN.RIGHT)

    add_paragraphs(s, Inches(0.7), Inches(2.0), Inches(11.9), Inches(3.6), [
        {'text': '问题', 'size': 14, 'bold': True, 'color': COLOR_GOLD},
        {'text': '在 Update 族中，Hermes 经常将修正记录在当前 session 的 transcript 中。下一 Episode 读取到的却是旧工件或无结构的 transcript 片段，导致用户已修正的旧答案仍然被返回。',
         'size': 12, 'color': COLOR_DARK},
        {'text': ' ', 'size': 6, 'color': COLOR_DARK},
        {'text': '干预', 'size': 14, 'bold': True, 'color': COLOR_GOLD},
        {'text': '在 Episode 关闭时提取最终的 binding key 或更新规则，写入为新的权威工件，'
                 '并同步（synchronously）flush 到持久存储中，覆盖旧值。下一全新会话因此只检索到修正值，而不会同时读到旧 + 新。',
         'size': 12, 'color': COLOR_DARK},
        {'text': ' ', 'size': 6, 'color': COLOR_DARK},
        {'text': '为什么重要', 'size': 14, 'bold': True, 'color': COLOR_GOLD},
        {'text': 'Update 能力是 Hermes+ 收益最大的能力：单项 E5 即在 Update 上贡献 Δ=+0.16，远高于其他单项机制对其他能力的贡献。'
                 '这与 Update 场景中「写入必须被下一会话真实看到」的强约束一致。',
         'size': 12, 'color': COLOR_DARK, 'italic': True},
    ])

    # 五项机制整体效果
    round_rect(s, Inches(0.5), Inches(5.95), Inches(12.3), Inches(1.35), COLOR_NAVY)
    add_text(s, Inches(0.7), Inches(6.05), Inches(11.9), Inches(0.4),
             'Hermes+（开启全部五项机制）整体效果', size=13, bold=True, color=COLOR_WHITE, font=CN)
    add_text(s, Inches(0.7), Inches(6.45), Inches(11.9), Inches(0.8),
             'Overall Δ 从 +0.13 升至 +0.15（基线 +0.02），Mech 从 0.64 升至 0.73（基线 +0.09），Update Δ 从 +0.12 大幅升至 +0.24。'
             '五项机制之间存在超加性组合效应。',
             size=12, color=COLOR_WHITE, font=CN)

# ====================================================================== #
# SLIDE 25: Hermes+ 结果
# ====================================================================== #
def slide_hermesplus_results():
    s = prs.slides.add_slide(BLANK)
    add_header_bar(s, 'Hermes+ 单项机制消融结果', 'Single-Mechanism Ablation')
    content_bg(s)

    add_text(s, Inches(0.5), Inches(1.2), Inches(12.3), Inches(0.4),
             '表 4：MiniMax-M2.7 固定下，单项机制与全量 Hermes+ 对比', size=13, bold=True, color=COLOR_NAVY, font=CN)

    header = ['配置', 'Memory Δ', 'Procedural Δ', 'Info Δ', 'Update Δ', 'Overall Δ']
    rows = [
        ('Base Hermes', '+0.26', '+0.05', '+0.09', '+0.12', '+0.13'),
        ('+ E1 (规划咨询)', '+0.32', '+0.05', '+0.05', '+0.13', '+0.14'),
        ('+ E2 (记忆渲染)', '+0.30', '−0.02', '+0.14', '+0.10', '+0.13'),
        ('+ E3 (技能路由)', '+0.17', '+0.10', '+0.15', '+0.05', '+0.12'),
        ('+ E4 (检索门控)', '+0.36', '+0.08', '+0.17', '+0.06', '+0.17'),
        ('+ E5 (Close Flush)', '+0.20', '+0.00', '+0.12', '+0.16', '+0.12'),
        ('Hermes+（全量）', '+0.27', '−0.02', '+0.12', '+0.24', '+0.15'),
    ]
    add_table(s, Inches(0.5), Inches(1.7), Inches(12.3), Inches(2.6),
              header, rows, [2.8, 1.7, 1.9, 1.5, 1.5, 1.7],
              row_colors=[COLOR_LIGHT_BG, COLOR_WHITE],
              highlight_rows={6}, highlight_color=RGBColor(0xe6, 0xff, 0xf0),
              font_size=11)

    # 解读
    round_rect(s, Inches(0.5), Inches(4.5), Inches(12.3), Inches(2.8), COLOR_BLUE_BG)
    rect(s, Inches(0.5), Inches(4.5), Inches(0.12), Inches(2.8), COLOR_BLUE)
    add_text(s, Inches(0.8), Inches(4.6), Inches(11.8), Inches(0.4),
             '逐项分析与组合效应', size=14, bold=True, color=COLOR_BLUE, font=CN)
    add_paragraphs(s, Inches(0.8), Inches(5.0), Inches(11.8), Inches(2.2), [
        {'text': 'E2 (Render) 给出最高 Memory 持久化开启得分 0.80；E3 (Route) 单项 Procedural Δ 最大 +0.10；E4 (Gate) Info Δ 最大 +0.17；E5 (Close) Update Δ 最强 +0.16。',
         'size': 12, 'color': COLOR_DARK},
        {'text': '完整 Hermes+ 在 Overall 上与 Base Hermes 持平 w/ 得分（0.66），但 Mech 从 0.64 升至 0.73，Update Δ 从 +0.12 翻倍至 +0.24。',
         'size': 12, 'color': COLOR_DARK},
        {'text': '机制之间存在超加性组合效应：单项 E5 在 Update 上 +0.16，全量组合后 Update Δ 升至 +0.24，远高于任何单项贡献。',
         'size': 12, 'color': COLOR_BLUE, 'bold': True},
        {'text': '跨模型泛化：Hermes+ 在 5 个基础模型中的 3 个上匹配或改进 Hermes 基线（MiniMax-M2.7、Claude Sonnet 4.6、GPT-5.4）。',
         'size': 12, 'color': COLOR_DARK},
    ])

# ====================================================================== #
# SLIDE 26: 机制交互
# ====================================================================== #
def slide_mechanism_interaction():
    s = prs.slides.add_slide(BLANK)
    add_header_bar(s, '机制交互：结构化记忆 × 程序路由', 'Mechanism Interaction')
    content_bg(s)

    # 现象
    round_rect(s, Inches(0.5), Inches(1.25), Inches(12.3), Inches(1.0), COLOR_ORANGE_BG)
    rect(s, Inches(0.5), Inches(1.25), Inches(0.12), Inches(1.0), COLOR_ORANGE)
    add_text(s, Inches(0.8), Inches(1.4), Inches(11.8), Inches(0.7),
             '聚焦诊断：移除 E2（结构化渲染）后，Procedural Δ 从 +0.085 升至 +0.108',
             size=15, bold=True, color=COLOR_ORANGE, font=CN, anchor='middle')

    # 原因
    add_text(s, Inches(0.5), Inches(2.45), Inches(12.3), Inches(0.4),
             '原因分析', size=15, bold=True, color=COLOR_NAVY, font=CN)
    add_paragraphs(s, Inches(0.5), Inches(2.85), Inches(12.3), Inches(1.5), [
        {'text': 'E2（结构化渲染）使 skill 写入的目的更清晰——当 E2 存在时，技能被过度结构化，导致 E3（技能路由）的贡献被掩盖。',
         'size': 13, 'color': COLOR_DARK, 'bullet': True},
        {'text': '移除 E2 让第一学习 Episode 创建 DB-migration 技能；后续 Episode 通过 skill_view 复用，程序复用率反而提升。',
         'size': 13, 'color': COLOR_DARK, 'bullet': True},
    ])

    # Full-minus-one 表
    add_text(s, Inches(0.5), Inches(4.5), Inches(12.3), Inches(0.4),
             '表 5：全量减一项的 Procedural Δ 对比', size=13, bold=True, color=COLOR_NAVY, font=CN)

    header = ['配置', 'Procedural Δ', '变化']
    rows = [
        ('Base Hermes', '+0.087', '基线'),
        ('Full Hermes+', '+0.085', '略低于基线'),
        ('w/o E1', '+0.084', '−0.003'),
        ('w/o E2', '+0.108', '+0.023 ↑'),
        ('w/o E3', '+0.062', '−0.025 ↓'),
        ('w/o E4', '+0.082', '−0.005'),
        ('w/o E5', '+0.042', '−0.045 ↓'),
    ]
    add_table(s, Inches(0.5), Inches(5.0), Inches(12.3), Inches(1.8),
              header, rows, [3.0, 3.0, 6.0],
              row_colors=[COLOR_LIGHT_BG, COLOR_WHITE],
              font_size=11)

    # 启示
    round_rect(s, Inches(0.5), Inches(6.9), Inches(12.3), Inches(0.4), COLOR_LIGHT_BG, COLOR_GRAY_BG, Pt(0.5))
    add_text(s, Inches(0.7), Inches(6.95), Inches(11.9), Inches(0.3),
             '💡 启示：持久化机制之间存在交互效应，不可视为 uniformly 可组合，需要按任务场景自适应路由。',
             size=12, color=COLOR_NAVY, italic=True, font=CN, anchor='middle')

# ====================================================================== #
# SLIDE 27: Part 6 标题
# ====================================================================== #
section_slide('Part 6', '结论与未来方向', 'Conclusion & Future Work')

# ====================================================================== #
# SLIDE 28: 核心结论
# ====================================================================== #
def slide_conclusion():
    s = prs.slides.add_slide(BLANK)
    add_header_bar(s, '核心结论', 'Key Conclusions')
    content_bg(s)

    # 顶部总结
    round_rect(s, Inches(0.5), Inches(1.25), Inches(12.3), Inches(0.9), COLOR_NAVY)
    add_text(s, Inches(0.5), Inches(1.3), Inches(12.3), Inches(0.8),
             '自我演化是能力特定的（capability-specific），不是能力无关的 universal 现象',
             size=16, bold=True, color=COLOR_WHITE, font=CN, align=PP_ALIGN.CENTER, anchor='middle')

    # 四大结论
    conclusions = [
        ('1', '能力特定性', '自我演化的程度与方向因能力维度（Memory/Procedural/Info/Update）和模型而异，'
         '不存在「对所有能力都生效」的统一机制。', COLOR_BLUE),
        ('2', '机制证据必要性', '相似的持久化差距可能隐藏不同的持久化路径。仅报告 task score / Δ 是不够的，'
         '必须同时报告 Mech 机制证据。', COLOR_GREEN),
        ('3', '诊断驱动设计', 'Hermes+ 作为诊断脚手架而非 universal 改进：'
         'Overall Δ 提升 +0.02 小于运行间变异，Update Δ 提升 +0.12 才是清晰信号。', COLOR_ORANGE),
        ('4', '机制交互不可忽视', '持久化机制之间存在超加性、亚加性与抵消效应，'
         '不可视为 uniformly 可组合，需要自适应路由与冲突检测。', COLOR_PURPLE),
    ]
    for i, (num, label, content, color) in enumerate(conclusions):
        y = Inches(2.3) + i * Inches(1.2)
        round_rect(s, Inches(0.5), y, Inches(12.3), Inches(1.1), COLOR_WHITE, COLOR_GRAY_BG, Pt(0.5))
        # 左侧数字色块
        rect(s, Inches(0.5), y, Inches(0.9), Inches(1.1), color)
        add_text(s, Inches(0.5), y + Inches(0.3), Inches(0.9), Inches(0.5),
                 num, size=26, bold=True, color=COLOR_WHITE, font=EN, align=PP_ALIGN.CENTER)
        # 标签
        add_text(s, Inches(1.6), y + Inches(0.1), Inches(3.5), Inches(0.4),
                 label, size=14, bold=True, color=color, font=CN)
        # 内容
        add_text(s, Inches(1.6), y + Inches(0.5), Inches(11.1), Inches(0.6),
                 content, size=12, color=COLOR_DARK, font=CN)

# ====================================================================== #
# SLIDE 29: 未来方向
# ====================================================================== #
def slide_future_work():
    s = prs.slides.add_slide(BLANK)
    add_header_bar(s, '未来研究方向', 'Future Work')
    content_bg(s)

    add_text(s, Inches(0.5), Inches(1.25), Inches(12.3), Inches(0.4),
             'PAST-Bench 提供了基础，但通往更强形式 RSI 的道路仍需进一步工作',
             size=13, color=COLOR_GRAY, font=CN, italic=True)

    futures = [
        ('① 生态效度与时间范围', COLOR_BLUE,
         '当前任务族均为合成、孤立评测。下一阶段需纳入人类撰写与交互衍生场景，'
         '扩展任务序列长度，并支持跨任务族经验影响，测试持久化智能体在更长视野下的有用状态维护、跨域经验迁移与记忆干扰。'),
        ('② 扩展能力空间', COLOR_GREEN,
         '当前四大能力是基础。未来的基准应评估智能体是否能够获取先前不可用的工具使用策略，'
         '构建与修订长程计划，协调多智能体经验，并改进「存什么、取什么、验什么、更什么」的元机制。'),
        ('③ 加强机制归因', COLOR_ORANGE,
         '当前的 Mech 机制证据分衡量与预期通路的一致性，而非因果必要性。'
         '未来可结合反事实干预（删除/替换/损坏候选工件并测行为变化），'
         '支持多种语义有效的持久化路径（如 memory vs skill vs policy），并扩大人类路径标注规模。'),
        ('④ 自适应持久化路由', COLOR_PURPLE,
         'Hermes+ 的能力特定、模型依赖行为表明持久化机制不应被视为 uniformly 可组合。'
         '未来智能体可在 accuracy、latency、token cost 约束下动态路由经验到 memory/skill/session history 等不同表面，'
         '检测冲突、冗余与陈旧状态。'),
    ]
    for i, (label, color, content) in enumerate(futures):
        y = Inches(1.85) + i * Inches(1.35)
        round_rect(s, Inches(0.5), y, Inches(12.3), Inches(1.25), COLOR_WHITE, COLOR_GRAY_BG, Pt(0.5))
        rect(s, Inches(0.5), y, Inches(0.12), Inches(1.25), color)
        add_text(s, Inches(0.8), y + Inches(0.1), Inches(3.0), Inches(0.4),
                 label, size=14, bold=True, color=color, font=CN)
        add_text(s, Inches(0.8), y + Inches(0.5), Inches(11.9), Inches(0.7),
                 content, size=12, color=COLOR_DARK, font=CN)

# ====================================================================== #
# SLIDE 30: 结束页
# ====================================================================== #
def slide_thanks():
    s = prs.slides.add_slide(BLANK)
    rect(s, 0, 0, prs.slide_width, prs.slide_height, COLOR_NAVY)
    rect(s, 0, Inches(3.4), prs.slide_width, Inches(0.06), COLOR_BLUE)

    add_text(s, Inches(0.5), Inches(1.6), Inches(12.3), Inches(1.2),
             '谢谢观看', size=60, bold=True, color=COLOR_WHITE, font=CN, align=PP_ALIGN.CENTER)
    add_text(s, Inches(0.5), Inches(2.7), Inches(12.3), Inches(0.5),
             'Thank you for your attention', size=18, color=RGBColor(0xa0, 0xae, 0xc0),
             font=EN, align=PP_ALIGN.CENTER, italic=True)

    add_text(s, Inches(0.5), Inches(3.6), Inches(12.3), Inches(0.5),
             'PAST-Bench 为研究持久化智能体如何从「保留经验」走向「通过经验系统性改进」',
             size=14, color=COLOR_WHITE, font=CN, align=PP_ALIGN.CENTER)
    add_text(s, Inches(0.5), Inches(4.0), Inches(12.3), Inches(0.5),
             '提供了评测与诊断基础',
             size=14, color=COLOR_WHITE, font=CN, align=PP_ALIGN.CENTER)

    # 链接
    add_text(s, Inches(0.5), Inches(5.0), Inches(12.3), Inches(0.4),
             '论文链接：https://arxiv.org/abs/2608.04003',
             size=14, color=COLOR_WHITE, font=EN, align=PP_ALIGN.CENTER, bold=True)
    add_text(s, Inches(0.5), Inches(5.4), Inches(12.3), Inches(0.4),
             'arXiv: 2608.04003v1',
             size=12, color=RGBColor(0xc0, 0xcc, 0xe0), font=EN, align=PP_ALIGN.CENTER, italic=True)

    add_text(s, Inches(0.5), Inches(6.5), Inches(12.3), Inches(0.4),
             'Q & A',
             size=24, bold=True, color=COLOR_WHITE, font=EN, align=PP_ALIGN.CENTER)


# ====================================================================== #
# 生成所有幻灯片
# ====================================================================== #
section_slide('Part 2', 'PAST-Bench 核心设计', 'Benchmark Design')  # 1
slide_pastbench_intro()                  # 2
slide_eval_pipeline()                    # 3
slide_scale()                            # 4
section_slide('Part 3', '四大评测能力维度', 'Four Core Capabilities')  # 5
slide_capability(1, '记忆', 'Memory',  # 6
    '测试智能体能否保留并查找日常条款（用户偏好、约束、单行策略、例外、先前案例决策）。'
    '在全新会话中触发任务，且触发措辞已从提示中移除，智能体需要主动从记忆存储中恢复并应用该条款。',
    '陈述性记忆路径（declarative pathway），对应人类认知科学中的「知道是什么」型记忆。'
    '评测 Episode 成功条件：智能体作为一次性「查找 + 应用」恢复该条款，而非通过工具调用重新推导。',
    '用户偏好采纳、约束保留、弱触发偏好采纳、先前案例回忆、例外列表回忆。'
    '5 个子族，共 41 个 Episode。',
    COLOR_BLUE2,
    related='何时查询交给能力 3；修订条款交给能力 4。本能力隔离「保留并应用单条事实」。')
slide_capability(2, '程序复用', 'Procedural Reuse',  # 7
    '测试智能体能否保留并重新执行多步技术工作流：SOP、剧本、构建/部署流水线、事件分流流程、'
    '工程化 SOP（incident triage、rollback、build pipeline 等）。',
    '程序性记忆路径（procedural pathway），对应人类认知科学中的「知道怎么做」型记忆。'
    '测试的是有序执行 + 正确工具组合，不是单次事实查找。',
    'SOP Bootstrap 01-06、Latent Rule Induction、Failure-to-Rule。'
    '8 个子族，共 64 个 Episode。',
    COLOR_BLUE,
    related='程序修订交给能力 4。本能力隔离「首次程序形成」与「按序执行」。')
slide_capability(3, '信息收集', 'Information Gathering',  # 8
    '测试当答案已经存在于持久化层中时，智能体是否在「正确时刻」主动检索？'
    '测试的不是「保留」，而是「在噪声上下文中触发查询」。',
    '与能力 1/2 的差别：相关工件在族开始前已预置到运行时持久化层（long-term memory、'
    'registered skills、indexed transcripts、home-state fixtures）。',
    'Release Decision Followup、Ops Exception Desk、Oncall Handoff Lookup、'
    'Temporary Waiver Audit、Change Freeze Followup、Kappa Integration Review。'
    '6 个子族，共 48 个 Episode。',
    COLOR_GREEN,
    related='每个族植入「通用默认值」：若不检索直接答，会得到 plausible 但错误的答案。')
slide_capability(4, '更新', 'Update',  # 9
    '测试智能体的「写覆盖写」能力：第二次权威写入能否覆盖第一次而不泄漏旧值。'
    '场景以陈旧事实/旧规则/过时 SOP 开头，交付权威修正后测试新值是否被使用。',
    '隔离「覆盖」这一持久化关键能力。Update 族包含一个 Update Episode 提供新值，'
    '后续 Evaluation Episode 在新会话中测试是否读到新值。',
    'Fact Correction、Rule Migration、Temporary Exception Pollution、Scoped Rule Migration、'
    'SOP Patch 01-02、Recall-then-Modify。7 个子族，共 51 个 Episode。',
    COLOR_ORANGE,
    related='测试点：新值被使用且旧值不泄漏。')
section_slide('Part 4', '实验结果与分析', 'Experimental Results')  # 10
slide_model_comparison()                 # 11
slide_framework_comparison()             # 12
slide_finding_1()                        # 13
slide_finding_2()                        # 14
section_slide('Part 5', 'Hermes+ 框架改进', 'Diagnosis-Driven Framework')  # 15
slide_failure_categories()               # 16
slide_mechanism_details()                # 17
slide_mechanism_e5()                     # 18
slide_hermesplus_results()               # 19
slide_mechanism_interaction()            # 20
section_slide('Part 6', '结论与未来方向', 'Conclusion & Future Work')  # 21
slide_conclusion()                       # 22
slide_future_work()                      # 23
slide_thanks()                           # 24

# 加页码
total = len(prs.slides)
for i, s in enumerate(prs.slides, 1):
    if i != total:  # 结束页不加页码
        add_text(s, Inches(12.6), Inches(7.18), Inches(0.6), Inches(0.25),
                 f'{i} / {total}', size=9, color=COLOR_GRAY, font=EN, align=PP_ALIGN.RIGHT)

# 保存
out = r'e:\zhizhuxia2\week13harness和skills\week13 skills和harness\cur\PAST-Bench_paperslides.pptx'
prs.save(out)
print(f'Saved: {out}')
print(f'Total slides: {total}')

# 同时复制到桌面
import shutil
dst = r'C:\Users\32234\Desktop\PAST-Bench_论文解读.pptx'
shutil.copy2(out, dst)
print(f'Copied to: {dst}')
