﻿# -*- coding: utf-8 -*-
"""从 arXiv ID/URL 下载论文 PDF。"""
import sys, re, urllib.request, os

def arxiv_id_from_url(s):
    m = re.search(r'arxiv\.org/(?:abs|pdf)/([\w./\-]+?)(?:\.pdf)?$', s)
    return m.group(1) if m else s

def main():
    if len(sys.argv) < 2:
        print("Usage: fetch_arxiv.py <arxiv_id_or_url> [out_path]")
        sys.exit(1)
    arxiv_id = arxiv_id_from_url(sys.argv[1])
    out = sys.argv[2] if len(sys.argv) > 2 else f"{arxiv_id.replace('/', '_')}.pdf"
    url = f"https://arxiv.org/pdf/{arxiv_id}"
    print(f"Downloading {url} -> {out}")
    urllib.request.urlretrieve(url, out)
    size = os.path.getsize(out)
    print(f"Done. Size: {size/1024:.1f} KB")

if __name__ == '__main__':
    main()
