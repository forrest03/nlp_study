﻿# -*- coding: utf-8 -*-
"""用 pdfplumber 提取论文全文到 txt。"""
import sys
try:
    import pdfplumber
except ImportError:
    print("请先安装：pip install pdfplumber", file=sys.stderr)
    sys.exit(1)

def main():
    if len(sys.argv) < 2:
        print("Usage: extract_text.py <pdf_path> [out_path]")
        sys.exit(1)
    pdf_path = sys.argv[1]
    out = sys.argv[2] if len(sys.argv) > 2 else pdf_path.replace('.pdf', '.txt')
    pages_text = []
    with pdfplumber.open(pdf_path) as pdf:
        for i, p in enumerate(pdf.pages, 1):
            t = p.extract_text() or ""
            pages_text.append(f"\n=== Page {i} ===\n{t}")
            print(f"Page {i}: {len(t)} chars")
    with open(out, 'w', encoding='utf-8') as f:
        f.write("\n".join(pages_text))
    print(f"Saved: {out}")

if __name__ == '__main__':
    main()
