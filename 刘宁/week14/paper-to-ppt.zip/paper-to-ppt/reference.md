﻿# 参考文档：论文解读 PPT 设计规范

## 1. 配色

| 名称 | HEX | 用途 |
|------|------|------|
| NAVY | #1a365d | 标题栏、章节标题、强调 |
| BLUE | #2b6cb0 | 一级色块、章节 1 |
| BLUE2 | #2c5282 | 二级色块 |
| GREEN | #38a169 | 章节 2、对照 |
| ORANGE | #dd6b20 | 章节 3、警示 |
| PURPLE | #8050c0 | 章节 4 |
| GOLD | #d69f00 | 章节 5、关键 |
| GRAY | #718096 | 副标题、注释 |
| DARK | #222233 | 正文 |
| BODY | #333344 | 默认文本 |
| LIGHT_BG | #f7fafc | 内容背景 |
| WHITE | #ffffff | 卡片背景 |

## 2. 字体

- 中文：`Microsoft YaHei`
- 英文：`Calibri`

## 3. 字号规范

| 元素 | 字号 |
|------|------|
| 封面主标题 | 60 pt |
| 封面副标题 | 28 pt |
| 章节标题（Section） | 44 pt |
| 页标题 | 24 pt |
| 页副标题 | 12 pt（italic） |
| 大段正文 | 14 pt |
| 列表点 | 12-13 pt |
| 表格头 | 12 pt（粗体） |
| 表格数据 | 11-12 pt |
| 页码 | 9 pt |

## 4. HTML 草稿结构

每张幻灯片是一个 `<section class="slide">`，包含：

- `<h1>` —— 标题（必填）
- `<h2>` —— 英文副标题（可选）
- `<ul class="points">` —— 多段要点（必填，建议 3+ 段完整句子）
- `<table class="data">` —— 数据表格（可选）
- `<aside class="callout">` —— 核心结论框（建议）
- `<aside class="warning">` —— 警示框（可选）

完整示例见 `examples.html`。

## 5. 内容硬性要求

### 必须满足

- 每张幻灯片至少 **3 段完整中文长句**（不止关键词）
- 每张幻灯片有 `<aside>` 总结句
- 关键数字（如表格）必须保留两位小数
- 引用论文作者、年份时给出准确信息

### 避免

- 仅用关键词 + 符号（如 `❌ Memory` `✅ Update`）
- 把整段论文摘要堆在一张幻灯片上
- 中英文混排不一致
- 表格行列过宽或过窄（建议 5-7 列宽）

## 6. python-pptx 渲染规范

### Helper 列表

| 函数 | 用途 |
|------|------|
| `rect(slide, x, y, w, h, fill, line=None, line_w=None)` | 实心矩形色块 |
| `round_rect(...)` | 圆角矩形 |
| `add_text(slide, x, y, w, h, text, **kw)` | 单段文本 |
| `add_paragraphs(slide, x, y, w, h, items, **kw)` | 多段文本，items 可为 str 或 dict |
| `add_header_bar(slide, title, subtitle=None)` | 顶部深蓝标题栏 |
| `section_slide(part_label, title, subtitle)` | 章节纯色标题页 |
| `add_table(slide, x, y, w, h, header, rows, col_widths, ...)` | 彩色表格 |
| `content_bg(slide)` | 浅灰内容背景 |
| `page_number(slide, idx, total)` | 右下角页码 |

### 常用参数

```python
# 标题
add_text(s, x, y, w, h, text, size=24, bold=True, color=COLOR_NAVY, font=CN)

# 正文段落
add_paragraphs(s, x, y, w, h, items, size=13, color=COLOR_DARK, font=CN, line_spacing=1.25)

# 卡片
round_rect(s, x, y, w, h, COLOR_BLUE_BG)
side_bar(s, x, y, Inches(0.12), h, COLOR_BLUE)  # 左侧色条

# 表格
add_table(s, x, y, w, h,
          header=['', '列1', '列2'],
          rows=[('A', '+0.23', '0.70')],
          col_widths=[2.8, 1.5, 1.5])
```

### 字体溢出

- 标题字号不要超过 18 pt，宽度不超过 12.5"
- 长段落拆成 2 张幻灯片
- 表格高度 = `Inches(2.5)` + 0.3/行，超过 7 行改用多张

## 7. 常见错误

| 错误 | 解决 |
|------|------|
| Windows cmd 输出乱码 | `sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')` |
| 中文字段显示成方框 | 安装 Microsoft YaHei 字体 |
| 段落超出边界 | 缩小字号 / 拆段 |
| 表格内容错位 | 检查 `col_widths` 总和等于 `w` |
