---
name: paper-to-ppt
description: 从论文（arXiv ID/URL 或本地 PDF）生成中文论文解读 PPT。流程为：获取 PDF → 提取文本 → LLM 分析生成 HTML 草稿 → 用 python-pptx 渲染为高密度中文 PPT（白底深色文本 + 章节色块 + 表格 + 页码）。Use when the user asks to "解读论文"、"生成论文 PPT"、"paper slides"、"讲解一篇论文"、提供 arXiv 链接/ID，或在本地提供 PDF 时。
---

# 论文 → PPT 生成 Skill

把一篇论文（arXiv 链接/ID 或本地 PDF）端到端转成中文论文解读 PPT。

## 总体流程

```
[输入] arXiv URL/ID | 本地 PDF
   │
   ├─ 1) 获取 PDF
   ├─ 2) 提取全文 + 关键字段
   ├─ 3) LLM 分析生成 HTML 草稿（含表格）
   ├─ 4) python-pptx 渲染 PPTX
   └─ 5) 复制到桌面 + 验证
```

## Step 1 — 获取论文 PDF

**arXiv ID/URL** → 自动从 `https://arxiv.org/pdf/{id}` 下载到本地。

**本地 PDF** → 直接使用用户提供的路径。

下载示例：

```python
import urllib.request, os, re
url = "https://arxiv.org/pdf/2608.04003v1"
out = r"e:\...\paper.pdf"
urllib.request.urlretrieve(url, out)
```

文件名清洗：`{id}__论文标题短写.pdf`。

## Step 2 — 提取全文

用 pdfplumber 提取每一页文本，逐页拼成一个 `.txt` 文件备用：

```python
import pdfplumber
with pdfplumber.open(pdf_path) as pdf:
    pages = [p.extract_text() or "" for p in pdf.pages]
full_text = "\n\n".join(pages)
```

**关键字段提取**（从首页 + abstract）：
- 标题（中英）
- 作者列表
- arXiv ID + 发表日期
- 一句话研究问题
- 三大方法论创新
- 关键数字/表格（用于 PPT 表格）

## Step 3 — LLM 分析生成 HTML 草稿

让 LLM 阅读 `full_text`，**输出一份带中文 PPT 草稿的 HTML**，而不是直接写 PPTX。理由：

- HTML 比 PPTX 文本密度高、信息损失少
- LLM 写文字自然，写 PPTX 的 shape 坐标很笨拙
- HTML 草稿 = 中间产物，方便人工校对

### HTML 草稿模板

HTML 草稿需**按页分段**，每段对应一张 PPT 幻灯片，每页用如下结构：

```html
<!-- Slide N: 标题 -->
<section class="slide">
  <h1>幻灯片大标题</h1>
  <h2>英文/副标题</h2>
  <ul class="points">
    <li><b>要点 1：</b>完整中文段落说明，不止关键词</li>
    <li><b>要点 2：</b>完整中文段落说明</li>
    <li><b>要点 3：</b>完整中文段落说明</li>
  </ul>
  <table class="data">
    <thead><tr><th>列1</th><th>列2</th><th>列3</th></tr></thead>
    <tbody>
      <tr><td>模型A</td><td>+0.23</td><td>0.70</td></tr>
    </tbody>
  </table>
  <aside class="callout">
    <b>核心结论：</b>一句话总结本页内容。
  </aside>
</section>
```

### 内容硬性要求（生成 PPTX 时常出问题）

1. **每张幻灯片必须有 3+ 条完整的中文长句段落**，不是仅关键词。旧版本痛点：PPT 出来只有短标签 → 用户说"少文字"。
2. **关键数字/表格**用 `<table>` 标出，PPTX 阶段会渲染为彩色表格。
3. **每张幻灯片有 `<aside class="callout">`**，作为右下角总结。
4. **章节顺序**灵活，但建议覆盖：研究背景、核心问题、方法设计、实验结果、关键发现、未来方向。
5. **默认跳过封面与目录页**（用户反馈：可直接删），从第 1 张内容页开始。

### HTML 草稿保存位置

```text
{工作目录}/{论文短标题}_html草稿.html
```

## Step 4 — 渲染 PPTX

参考并复用 `scripts/render_pptx.py` 中的所有 helper：
- `rect`, `round_rect`（彩色色块）
- `add_text`, `add_paragraphs`（多段文本）
- `add_header_bar`（顶部深蓝标题栏）
- `section_slide`（章节标题页，纯色背景）
- `add_table`（彩色表格）
- `content_bg`（浅灰内容背景）

### 版式固定规范

| 元素 | 规范 |
|------|------|
| 画布 | 13.333" × 7.5" (16:9) |
| 主色 | NAVY `#1a365d`, BLUE `#2b6cb0` |
| 辅色 | GREEN `#38a169`, ORANGE `#dd6b20`, PURPLE `#8050c0`, GOLD `#d69f00` |
| 中文字体 | Microsoft YaHei |
| 英文字体 | Calibri |
| 标题栏 | 深蓝条 + 蓝色细线，副标题灰色斜体 |
| 页码 | 右下角 `n / total`，最后一张不加 |
| 结束页 | 无页码，"谢谢观看" + Q&A + arXiv 链接 |

### 常见陷阱

- **编码**：Python 必须 `# -*- coding: utf-8 -*-` + `sys.stdout = io.TextIOWrapper(...)`，否则 Windows cmd 跑出来乱码。
- **整段文本溢出**：若中文段落太长，用 `add_paragraphs` 并控制字号 12-14、行距 1.25、`space_after=2`。
- **段落太长放不下**：拆成两张幻灯片，不要硬塞。
- **每页字数参考**：单张 100–250 中文字符为佳，表格页可少一些。

### 渲染流程

1. 解析 HTML 草稿（按 `<section class="slide">` 切片）
2. 映射章节元素到 PPTX 组件：
   - `<h1>` → `add_header_bar` 标题
   - `<h2>` → 副标题
   - `<ul class="points">` → `add_paragraphs`（自动 bullet）
   - `<table class="data">` → `add_table`（彩色单元格）
   - `<aside class="callout">` → 底部圆角卡片
3. 末页追加固定"谢谢观看"页
4. 加页码，保存

完整脚本参考 `scripts/render_pptx.py`。

## Step 5 — 输出与验证

```python
out = r"{工作目录}/{论文短标题}.pptx"
prs.save(out)
shutil.copy2(out, r"C:\Users\{当前用户名}\Desktop\{论文短标题}_论文解读.pptx")
```

验证步骤：
1. 重新打开 PPTX，用 python-pptx 检查每页文字数量
2. 检查最后一页是"谢谢观看"
3. 检查页码范围正确

## 常见交互

| 用户反馈 | 处理 |
|---------|------|
| "PPT 里少文字" | 强化 LLM 提示词：「每张幻灯片至少 3 段完整中文段落，不止关键词」 |
| "前 N 张删掉" | 直接在 `gen_pptx_v2.py` 里删除对应的 `slide_xxx()` 调用，重新生成 |
| "回滚到上一个版本" | 改回之前的脚本，重新跑 |
| "加封面/目录/页码" | 修改对应 helper |

## 配套文件

- `scripts/fetch_arxiv.py` — arXiv 下载
- `scripts/extract_text.py` — pdfplumber 提取
- `scripts/render_pptx.py` — python-pptx 渲染（含全部 helper 与示例幻灯片）
- `reference.md` — 配色、版式、HTML 草稿格式详细规范

## 依赖

```text
python-pptx>=0.6.21
pdfplumber>=0.10.0
```

Windows + 中文环境已验证可工作。